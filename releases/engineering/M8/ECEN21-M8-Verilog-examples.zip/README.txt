ECEN21 Toolkit M8 generated Verilog examples

These17files were actually exported by the production add-in inside the pinned
fx-CG50 emulator,matched byte-for-byte to host generation,and consumed by
independent Icarus-g2001 behavior benches. They are examples,not physical FPGA or
calculator USB verification. Per-file parameters are in parameters.json.

Include only one source variant per module family;variants share module names.
Use named parameter overrides to instantiate multiple widths of one module.
The structural adder file includes its one-bit primitive. WIDTH is1..32;ordinary
encoders have a separate valid flag;clock/reset choices are explicit. No sequential
power-up value is assumed. Reset/load before relying on q. Source is plain ASCII
with complete original lines;screen wrapping is not part of these files.

Full stage records: TESTING.md and docs/M8-USER-ACCEPTANCE.zh-CN.md in the project.
