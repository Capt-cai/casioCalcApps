// ECEN21 Toolkit: Behavioral full adder
// Verilog-2001. Pin order/priority are explicit below.
module ecen21_add_b #(parameter integer WIDTH=1)(
  input wire [WIDTH-1:0] a,b, input wire cin,
  output wire [WIDTH-1:0] sum, output wire cout);
// synthesis translate_off
initial begin
  if (WIDTH<1 || WIDTH>32) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
assign {cout,sum}={1'b0,a}+{1'b0,b}+cin;
endmodule

