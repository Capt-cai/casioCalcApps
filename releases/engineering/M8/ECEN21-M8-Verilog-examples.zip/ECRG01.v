// ECEN21 Toolkit: One-hot ring counter
// Verilog-2001. Pin order/priority are explicit below.
// One-hot seed; enable holds/rotates. Reset establishes initial state.
module ecen21_ring #(parameter integer WIDTH=1,
  parameter integer SEED_INDEX=0)(
  input wire clk,rst,enable, output reg [WIDTH-1:0] q);
localparam [WIDTH-1:0] SEED={{(WIDTH-1){1'b0}},1'b1} << SEED_INDEX;
// synthesis translate_off
initial begin
  if (WIDTH<1 || WIDTH>32 || SEED_INDEX<0 || SEED_INDEX>=WIDTH) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
always @(posedge clk) begin
  if (rst) q <= SEED;
  else begin
    if(enable) q <= (q << 1) | (q >> (WIDTH-1));
  end
end
endmodule

