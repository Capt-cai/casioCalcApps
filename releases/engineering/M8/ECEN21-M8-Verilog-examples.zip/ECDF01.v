// ECEN21 Toolkit: D flip-flop
// Verilog-2001. Pin order/priority are explicit below.
// q starts unspecified; reset/capture establishes state.
// rst is ignored when reset mode is NONE.
module ecen21_dff #(parameter RESET_VALUE=1'b1)(
  input wire clk,rst,d, output reg q);
// synthesis translate_off
initial begin
  if (RESET_VALUE !== 1'b0 && RESET_VALUE !== 1'b1) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
// Shared FF characteristic rows: Q A B -> next (active edge)
// 0 0 0 -> 0
// 0 1 0 -> 1
// 1 0 0 -> 0
// 1 1 0 -> 1
always @(negedge clk or negedge rst) begin
  if (!rst) q <= RESET_VALUE;
  else begin
    q <= d;
  end
end
endmodule
