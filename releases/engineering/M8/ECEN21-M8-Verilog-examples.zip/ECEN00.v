// ECEN21 Toolkit: Ordinary encoder
// Verilog-2001. Pin order/priority are explicit below.
// Ordinary active-high one-hot encoding. No priority.
// Code ORs active indices even if invalid; only use when valid=1.
module ecen21_encoder #(parameter integer INPUTS=4)(
  input wire [INPUTS-1:0] in,
  output reg [(INPUTS==8?3:2)-1:0] code, output reg valid);
integer i,ones;
// Default INPUTS mapping from the shared encoder model:
// I0 alone -> code0, valid1
// I1 alone -> code1, valid1
// I2 alone -> code2, valid1
// I3 alone -> code3, valid1
// synthesis translate_off
initial begin
  if (INPUTS!=4 && INPUTS!=8) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
always @* begin
  code=0; ones=0;
  for(i=0;i<INPUTS;i=i+1) begin
    if(in[i]) begin code=code|i; ones=ones+1; end
  end
  valid=(ones==1);
end
endmodule

