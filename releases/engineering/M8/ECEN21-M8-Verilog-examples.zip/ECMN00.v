// ECEN21 Toolkit: Modulo-N counter
// Verilog-2001. Pin order/priority are explicit below.
// Synchronous reset. enable=0 holds; out-of-range states recover to0.
// WIDTH defaults to safe ceil(log2(MODULUS)), with minimum1.
module ecen21_modulo #(parameter integer MODULUS=12,
  parameter integer EXTRA_BITS=0,
  parameter integer WIDTH=EXTRA_BITS+(
    (MODULUS<=2)?1:
    (MODULUS<=4)?2:
    (MODULUS<=8)?3:
    (MODULUS<=16)?4:
    (MODULUS<=32)?5:
    (MODULUS<=64)?6:
    (MODULUS<=128)?7:
    (MODULUS<=256)?8:
    (MODULUS<=512)?9:
    (MODULUS<=1024)?10:
    (MODULUS<=2048)?11:
    (MODULUS<=4096)?12:
    (MODULUS<=8192)?13:
    (MODULUS<=16384)?14:
    (MODULUS<=32768)?15:
    16))(input wire clk,rst,enable, output reg [WIDTH-1:0] q);
// synthesis translate_off
initial begin
  if (MODULUS<1 || MODULUS>65535 || EXTRA_BITS<0 || EXTRA_BITS>31 || WIDTH<1 || WIDTH>32 || (64'd1<<WIDTH)<MODULUS) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
// Selected calculator width=4; override WIDTH if a wider counter is wanted.
always @(posedge clk) begin
  if (rst) q <= {WIDTH{1'b0}};
  else begin
    if(enable) begin
      if(q>=MODULUS-1) q <= 0;
      else q <= q+1'b1;
    end
  end
end
endmodule
