// ECEN21 Toolkit: JK flip-flop
// Verilog-2001. Pin order/priority are explicit below.
// q starts unspecified; reset/capture establishes state.
// rst is ignored when reset mode is NONE.
module ecen21_jkff #(parameter RESET_VALUE=1'b0)(
  input wire clk,rst,j,k, output reg q);
// synthesis translate_off
initial begin
  if (RESET_VALUE !== 1'b0 && RESET_VALUE !== 1'b1) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
// Shared FF characteristic rows: Q A B -> next (active edge)
// 0 0 0 -> 0
// 0 0 1 -> 0
// 0 1 0 -> 1
// 0 1 1 -> 1
// 1 0 0 -> 1
// 1 0 1 -> 0
// 1 1 0 -> 1
// 1 1 1 -> 0
always @(posedge clk) begin
    case ({j,k})
      2'b00: q <= q;
      2'b01: q <= 1'b0;
      2'b10: q <= 1'b1;
      2'b11: q <= ~q;
      default: q <= 1'bx;
    endcase
end
endmodule
