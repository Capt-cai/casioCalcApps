// ECEN21 Toolkit: Structural full adder
// Verilog-2001. Pin order/priority are explicit below.
module ecen21_fa1(input wire a,b,cin, output wire sum,cout);
wire p;
assign p=a^b;
assign sum=p^cin;
assign cout=(a&b)|(p&cin);
endmodule

module ecen21_add_s #(parameter integer WIDTH=5)(
  input wire [WIDTH-1:0] a,b, input wire cin,
  output wire [WIDTH-1:0] sum, output wire cout);
// synthesis translate_off
initial begin
  if (WIDTH<1 || WIDTH>32) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
// Bit0 is LSB; each stage consumes previous carry.
wire [WIDTH:0] carry;
assign carry[0]=cin;
assign cout=carry[WIDTH];
genvar i;
generate for(i=0;i<WIDTH;i=i+1) begin: bit_stage
  ecen21_fa1 fa(.a(a[i]),.b(b[i]),.cin(carry[i]),
    .sum(sum[i]),.cout(carry[i+1]));
end endgenerate
endmodule
