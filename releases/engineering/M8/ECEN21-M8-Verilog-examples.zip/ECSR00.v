// ECEN21 Toolkit: Universal shift register
// Verilog-2001. Pin order/priority are explicit below.
// Priority: reset > load > right > left > hold.
// Right inserts serial_left at MSB; left inserts serial_right at LSB.
// q starts unspecified; reset or parallel load establishes state.
module ecen21_shift #(parameter integer WIDTH=5)(
  input wire clk,rst,load,shift_right,shift_left,
  input wire serial_left,serial_right,
  input wire [WIDTH-1:0] parallel, output reg [WIDTH-1:0] q);
// synthesis translate_off
initial begin
  if (WIDTH<1 || WIDTH>32) begin
    $display("ECEN21 parameter error");
    $finish;
  end
end
// synthesis translate_on
always @(posedge clk) begin
  if (rst) q <= {WIDTH{1'b0}};
  else begin
    if(load) q <= parallel;
    else if(shift_right)
      q <= (q >> 1) | ({{(WIDTH-1){1'b0}},serial_left} << (WIDTH-1));
    else if(shift_left)
      q <= (q << 1) | {{(WIDTH-1){1'b0}},serial_right};
    else q <= q;
  end
end
endmodule

