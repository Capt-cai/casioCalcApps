# ECEN21 Toolkit — Milestone 2B

A native fx-CG50 Boolean solver for **2–4 variables**. M2A was accepted by the user; its binary/evidence remains under `.phase1/milestones/M2A/` and `.phase1/ecen21/`. M2B replaces its minimal mask-only UI with expressions, ternary truth tables, Gray-order Karnaugh maps, exact SOP/POS and group explanations. The original upstream Logic/common sources and exact engine remain unchanged.

## Keys and views

| Key | Action |
|---|---|
| F1 / F2 / F3 | Expression editor / truth table / K-map; navigating preserves data |
| F4 | Open exact result; press again in the result view to switch SOP/POS |
| F6 | Compute both exact forms, verify all cared rows; editor EXE also solves |
| F5 in editor | **USE EX**: explicitly replace manual table/DC data using saved expression |
| F5 in table | Cycle variable count 4 -> 2 -> 3 -> 4 |
| F5 in result/map | Open selected solution's group explanation |
| F5 in group explanation | Return to map with that group selected |
| OPTN | Samples/About menu; 1–6 load a sample, any other key returns unchanged |
| EXIT | Quit to calculator OS (physical behaviour requires user verification) |

Expression entry uses X,theta,T/log/ln/sin for A/B/C/D; 0/1 for constants; + for OR, multiplication for AND, power ^ for XOR, division for prefix `!`, decimal point for postfix `'`, and the parenthesis keys. No SHIFT/ALPHA is needed. AND may also be implicit (`AB`). Precedence is NOT, AND, XOR, OR; parentheses override it. LEFT/RIGHT move the insertion cursor, DEL removes the preceding character, and AC clears the expression. Typing inserts at the cursor (it does not use M2A's replace-first-digit convention). Maximum length is 79 characters; empty/invalid input clears current truth data and solutions and shows its first error position. Expressions may only use variables within the selected active count.

In the table, UP/DOWN select a row; LEFT/RIGHT switch blocks for 16 rows. EXE cycles **0 -> 1 -> X -> 0**. The map uses arrow keys to select a cell and EXE to edit the same row. Editing invalidates both solutions until F6 is pressed. On the map, +/- cycle through the selected solution's groups; orange marks the current group and blue the editing cursor. Wraparound groups can appear at opposite map edges with the same colour. SOP groups cover 1/X; POS groups cover 0/X. F5 explains every group using its fixed variables, covered rows, included X rows and corresponding term/clause; UP/DOWN cycles all groups, including beyond the first six. `*` in the explanation means the variable is free and drops from the cube.

Results retain all characters and break between terms/clauses where possible. UP/DOWN cycles pages if required. POS uses complemented zero-group clauses; the explanation states this explicitly. Group steps describe cube-to-term reduction, not a full algebraic proof. All-DC data may legitimately yield SOP `0` and POS `1`, with zero cared rows; those are two allowed completions of an unspecified function.

## Source and variable-count semantics

The header marks **EXPR** or **MANUAL**. A manual table retains saved expression text but does not apply it just because EDIT is opened. Only an actual expression edit or explicit USE EX reapplies text and clears DC. Samples explicitly replace the current work. There is no disk persistence of input.

Changing variable count in EXPR mode reevaluates the expression and reports variables now outside the active count. In MANUAL mode, reducing variables retains low-numbered rows and discards higher ones; increasing adds zero rows. This is an explicit bounded-table reinterpretation, **not Boolean elimination**. The table's hint distinguishes these modes. All views use the same ON/DC data and A as the most significant row bit.

## Samples and known results

| OPTN then | Sample | Selected expected result |
|---|---|---|
| 1 | `AB+C`, four variables | SOP `C+AB` (2 terms,3 literals); POS `(B+C)*(A+C)` (2 clauses,4 literals) |
| 2 | `A'(B^C+C^D)`, ON mask007E | SOP `A'C'D+A'BD'+A'B'C` (3 terms,9 literals); POS3 clauses,7 literals |
| 3 | Two variables: row0=X,row1=1,others0 | SOP `A'`, POS `(A')`, each1 literal;3 cared rows |
| 4 | `A^B^C^D` | 8 terms/clauses,32 literals; all8 groups accessible |
| 5 / 6 | Constant0 / Constant1 | Both forms evaluate to the constant; cover counts follow engine conventions |

Loading a sample does not solve it; F6 or editor EXE computes it.

## Build and verify

```sh
bash apps/ecen21/tests/run-host.sh
bash experiments/boolean/run-tests.sh
bash scripts/toolchain-build-m2b.sh
/opt/homebrew/bin/python3.11 scripts/verify-m2b.py
ctest --test-dir .phase1/emulator-build --output-on-failure
```

Use the existing cached pinned ARM64 Docker image and native emulator from Phase1. Docker Desktop must run; host verification needs Pillow. Artifacts/evidence use `.phase1/ecen21-m2b/`; production is `artifacts/ECEN21.g3a`. `EC21Test.g3a` is test-only and is not the user application. Builds run on Linux tmpfs with no network and preserve all prior artifacts; timestamps can change binary hashes. CMake also follows standard repository `casio_app` conventions for a native fxSDK installation, but only the container route is verified on this Mac.

`src/solver.[ch]` is portable and separate from `src/main.c`; the production links the same unchanged `experiments/boolean/exact_boolean.c` used by the independent oracle tests. Shared fixtures run on both host and SuperH, with a checked report file rather than screenshot existence alone. See `docs/M2B-MODEL.md`, root `TESTING.md`, and `docs/M2B-USER-ACCEPTANCE.zh-CN.md` for semantics, verified results and physical-user instructions. Existing MIT/font attribution is preserved. Hardware peak stack, worst-case latency and unreported OS/USB behaviour remain unmeasured; emulation is not hardware certification.
