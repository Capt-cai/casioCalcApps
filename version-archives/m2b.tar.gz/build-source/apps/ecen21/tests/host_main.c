#include "controller_checks.h"
#include "solver_checks.h"
#include <stdio.h>

int main(void)
{
    unsigned checks;
    int failed = ec_run_checks(&checks);
    printf("%s: ECEN21 controller; %u checks; failure line %d\n",
        failed ? "FAIL" : "PASS", checks, failed);
    int solver_failed = bs_run_checks(&checks);
    printf("%s: ECEN21 M2B solver; %u checks; failure line %d\n",
        solver_failed ? "FAIL" : "PASS", checks, solver_failed);
    return failed || solver_failed ? 1 : 0;
}
