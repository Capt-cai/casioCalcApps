# ECEN21 Toolkit - M5

Native offline fx-CG50 Boolean, fixed-width numeric, single flip-flop and bounded
counter/sequential design tools. M2A/M2B/M3/M4 are accepted. M5 engineering work
adds a composed design workflow, not a replacement for accepted computational
cores. Original Logic/Base-N/common and accepted Boolean/numeric/FF source files
remain unchanged; M3 is frozen at8/16/32 bits.

## Navigation

Home keys1/F1 Boolean,2/F2 Binary,3/F3 Flip-flops,4/F4 Sequential. UP/DOWN selects
one of four entries, EXE opens it. Tool EXIT returns home preserving in-memory
state; home EXIT returns to OS. Fresh launch resets all tools. No disk persistence.
Previous tool controls remain as documented in their accepted milestone guides.

## M5 sequential design

2-3 state bits Qn-1..Q0,0-1control E, per-bit D/T/JK/SR, common rising/falling
edge, RETURN/HOLD/DC unused-state policy, initial/recovery states and optional
Z0/Z1 equations. Cycle entry supports digits or separators and an optional final
repeated start. A cycle has2..2^bits unique states; repeated internal states,
missing equations,bad syntax/ranges/capacities fail clearly and invalidate old
answers. Reverse equations specify every input pin using the explicit variable
map shown in the editor; optional outputs use present Q/E, not next Q.

| Key | Meaning |
| --- | --- |
| F1 SETUP | Problem settings/field list; UP/DOWN select, EXE cycles scalar or opens full text editor |
| F2 TABLE | State -> excitation -> output table; from other views opens state table |
| F3 EQS | Exact per-pin SOP/POS equations, costs and variable map |
| F4 MAP | Selected pin K-map/groups; EXE opens/closes group details |
| F5 MORE |1trace,2connections,3recovery/traps,4outputs,5help |
| F6 SOLVE | Validate all active fields, synthesize/analyze, verify and build connections |
| +/- | Switch actual SOP/POS completed circuit in result views; recompute connection snapshot |
| LEFT/RIGHT | Select input pin; UP/DOWN changes page (map changes group) |
| OPTN | Eight explicit replace-current-problem examples; other keys cancel |
| EXIT | Home, retain problem/results/views |

Editor: AC/F1 clear,DEL backspace,LEFT/RIGHT cursor,EXE/F6 save,EXIT cancel. Cycle
states use decimal digits0-7 (e.g03570); decimal point inserts a comma. Binary E
timeline accepts up to32 entries, one value per active clock; empty uses fixed E
until a cycle/invalid state. Input/output expressions allow up to79characters:
X/log/ln/sin -> A/B/C/D, / -> NOT, x -> AND,+ -> OR,^ -> XOR,. -> postfix NOT,
parentheses and0/1. A maps highest Q, subsequent letters lower Q, E last if used.
Full text is visible in the editor; setup list displays field previews.

Scalars cycle in place. Changing bit count/control/type retains source fields;
repair newly incompatible active fields rather than silently changing the
problem. Inactive branch/equation/timeline fields are retained but ignored.
All accepted source edits/settings invalidate derived output until F6. Cancelled
text editing leaves the existing solved problem untouched. Input errors show
field and1-based character position; any key returns to setup for repair.

RETURN directs every unused state to the chosen recovery state (default0); a
recovery state outside the desired cycle can create a trap and is reported.
HOLD leaves unused states in self-loops. DC permits arbitrary unused transitions:
SOP andPOS completions are separately replayed and may differ. Never infer a
recovery guarantee. Excitation X is a legal input don't-care; an undefined SR
next vector displays ! and stops a trace. SR11 reverse rows are analysis results,
not successful state transitions. Initial state is a simulation start/hardware
initialization requirement, not a fabricated reset circuit.

State table shows required and actual completed next vectors. Excitation view
shows required legal input constraints and implemented pin values per selected
form. Equations use existing exact per-pin group-count/literal objectives, not a
global minimum-gate promise. K-map shows Gray axes, original pin ON/DC rows and
chosen cube groups; details list covered/DC row numbers and product/clause.
Trace reports transient prefix/cycle period for fixed E; E timelines never infer
cycles from repeated Q. Recovery view enumerates every start/E and flags traps
or SR-invalid paths. Connections give explicit FF/pin,constant,feedback and
AND/OR/NOT/XOR node wiring, including shared parity/complement functions.

### Examples (OPTN then1-8, F6 computes)

| Sample | Specification / expected result |
| --- | --- |
|1|3bit T03570; RETURN0; period4;unused1/2/4/6 return0|
|2|3bit JK0147350; RETURN0; period6|
|3|Q2D,Q1T,Q0JK;031254760; period8|
|4|2bit T; E0:02310,E1:01320; T0=E XOR Q1 XOR Q0,T1=!T0; oneXOR3+oneNOT wiring|
|5|Reverse p33; T1=B+!A,J0=!B*A,K0=!B+A,Z0=B;00->10->11->00;Z0=Q0|
|6|3bit+E,mixed;E0:03570,E1:014763250; timeline01011010;all16rows|
|7|2bit D swap;D1=B,D0=A;initial01;01->10->01;simultaneous oldQ sampling|
|8|Reverse SR11 onQ1;allnext vectors undefined;trace stops|

## Build and verification

```sh
bash apps/ecen21/tests/run-host.sh
bash apps/ecen21/tests/run-sequential-exhaustive.sh
bash apps/ecen21/tests/run-numeric-exhaustive.sh
bash experiments/boolean/run-tests.sh
bash scripts/toolchain-build-m5.sh
/opt/homebrew/bin/python3.11 scripts/verify-m5.py
ctest --test-dir .phase1/emulator-build --output-on-failure
```

Reuse pinned cached ARM64Docker image and native pinned emulator; no hostSDK
installation assumed. Generated files/logs/source manifests are isolated under
`.phase1/ecen21-m5/`. User artifact: `artifacts/ECEN21.g3a`;EC21Test.g3a is test-only.
Generic/older build aliases forward to current M5; accepted helpers/evidence and
binaries remain archived under `.phase1/milestones/`. M4 additionally has an
immutable accepted checkpoint bundle; rebuilding includes new timestamp metadata.

`scripts/verify-m5.py` compares shared target-written report with host, runs all
three older UI suites with archived pixel comparisons, and runs M5 scenarios in
three independent scripts (`screenshots/m5-a/b/c.script`) to respect the pinned
emulator's512-step/8192path-byte limits. The target suite has an explicit bounded
pending script event so it can finish beyond the emulator's default500ms tail;
verification requires a real report and rejects script-tail termination.

Portable model: `sequential.[ch]`; exact and parser APIs are reused unchanged.
`seq_connections.[ch]` builds a bounded graph and line descriptions independently
replayed by tests; native `sequential_ui.c` owns display/input only. Test sources
are excluded from production. See `docs/M5-MODEL.md`,`docs/M5-CONNECTIONS.md`,
rootTESTING and `docs/M5-USER-ACCEPTANCE.zh-CN.md` for evidence/limits/instructions.
No latch/ripple clocks,waves,async reset,Verilog orhigher-state-bit synthesis is
included. No physical latency/peak-memory/USB/OS claim follows from emulation.
