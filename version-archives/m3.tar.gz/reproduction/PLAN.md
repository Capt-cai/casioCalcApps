# ECEN21 Toolkit plan

**Phase 1 software verification: COMPLETE.** Unchanged Logic was freshly compiled in a pinned ARM64 Linux container on this Apple Silicon Mac, and the new binary passed native macOS emulator verification. A fully native macOS compiler installation and physical calculator validation remain unverified. The checked-in prebuilt was preserved.

## Completed parallel work

Exactly two subagents were actually spawned in parallel, finished, and were reviewed by the lead, with separate write ownership:

| Workstream | Owner | Files |
|---|---|---|
| Complete toolchain, fresh Logic build, fresh-binary emulator verification | Agent A — Toolchain Engineer | `tools/toolchain/`, `scripts/toolchain-*`, `docs/TOOLCHAIN.md`, ignored `.phase1/toolchain/`; generated Logic build files only |
| Exact minimization design, portable prototype, independent host tests | Agent B — Algorithm Engineer | `experiments/boolean/`, `docs/BOOLEAN-MINIMIZATION.md` |
| Review, independent verification, integration and project status | Lead Engineer | `PLAN.md`, `PROGRESS.md`, `TESTING.md` and review logs under ignored `.phase1/lead/` |

Application source under `apps/logic/` and `common/`, and the checked-in distribution binary, must remain unchanged during this work.

## Acceptance gates and results

1. **Passed:** dependency versions, image digest, embedded Git revisions and commands recorded in [TOOLCHAIN.md](docs/TOOLCHAIN.md).
2. **Passed:** a clean source copy without prebuilt add-ins compiled, linked and packaged successfully. Fresh artifact: `.phase1/toolchain/artifacts/Logic.g3a`; its hash and evidence are in [TESTING.md](TESTING.md).
3. **Passed:** agent and lead independently ran the fresh binary in the native emulator. All five demo screens exactly matched reference pixels. The known trailing unused-key diagnostic is retained; physical behaviour is not inferred from emulation.
4. **Passed for the documented domain:** isolated exact SOP/POS/don't-care prototype reviewed; 153,092 host minimizations passed independent-oracle checks under ASan/UBSan. SuperH compilation also passed. Four-variable don't-care coverage is sampled; target runtime is pending.
5. **Passed:** both agents finished; lead reviewed source isolation/provenance, reran host tests and final fresh-binary emulation, checked pixels, and verified original source/prebuilt hashes.

## Milestone 2A — Minimal ECEN21 Application (engineering complete; user accepted)

Implement a separate `apps/ecen21/` with repository `casio_app`/shared UI conventions. Link the existing verified `experiments/boolean/exact_boolean.c` directly rather than duplicating it. A portable controller owns a bounded four-digit hexadecimal ON-mask input for four variables; EXE computes exact SOP and validates all 16 rows. Provide the known `0x007e` example, zero/all-one inputs, result/cost display, About and exit. Keep the computation/controller independent of gint input/display.

Acceptance criteria:

1. Repository-level persistent workflow instructions installed; existing Phase 1 findings/evidence preserved.
2. Fresh `ECEN21.g3a` build using the pinned ARM64 toolchain, with source manifest, target/header checks and recorded hash.
3. Functional scripted emulator interaction: input/edit, actual calculate, clear/recalculate, known counterexample, constants, About and exit. Verify target results against independently known fixtures, not just screenshot existence.
4. Existing host exact-engine regression suite and new controller tests pass; exercise empty/bounded input, stale-result invalidation and correct outputs.
5. Inspect rendered screens, record resource estimates/emulator observations and explicitly leave physical calculator behaviour unverified.
6. Original Logic/shared sources and checked-in binaries remain unchanged. Update project records with actual results and stop.

All six acceptance criteria passed on November 12, 2026. Fresh production output: `.phase1/ecen21/artifacts/ECEN21.g3a` (72,532 bytes). Host algorithm regression, 218 host/controller checks, the same 218 checks running as SuperH code, and the production emulator UI smoke test passed. See `TESTING.md` for final hash, evidence and limits. The production app exposes only editable four-variable ON-mask SOP minimization. The separately built target-test harness is excluded from production.

The user explicitly stated “M2A验收通过 批准进入M2B”. **M2A user acceptance: passed. M2B approval: granted.** Prior build/test evidence and artifact are preserved under `.phase1/milestones/M2A/` in addition to the original `.phase1/ecen21/`. This records the user's acceptance without inventing agent-observed hardware measurements. Handoff reference: [M2A user acceptance guide](docs/M2A-USER-ACCEPTANCE.zh-CN.md).

## Milestone 2B — Complete Boolean Solver (engineering complete; user accepted)

Scope is bounded to 2–4 variables: expression editor, editable truth table with 0/1/X, synchronized Gray-order K-map, exact SOP/POS using the verified engine, and group-to-term explanation (not a full algebraic proof). Preserve upstream Logic/common/engine and M2A delivery evidence.

Acceptance criteria:

1. Expressions support A–D, constants, parentheses, NOT, AND, XOR and OR with documented precedence and bounded input. Syntax errors identify a position and invalidate old tables/results.
2. Truth-table cells cycle 0 -> 1 -> X -> 0; K-map shows the same row values. Expressions and manual-table source are explicit, so navigation never silently discards edits. Active variable counts 2/3/4 have defined transition semantics.
3. Both exact SOP/POS are generated and verified on all cared rows. Switching result form does not discard source data; constants, all-DC and known nonminimal-greedy fixtures are covered.
4. K-map grouping is tied to the selected solution; every group can be inspected with covered minterms/DC and its product term or POS clause. Long results/groups are paginated or scrolled without silent truncation.
5. Strict sanitized host tests cover parser/controller/K-map invariants plus existing algorithm regression. Shared integration fixtures also run as SuperH code. Production emulator scripts cover expressions, errors, 0/1/X editing, K-map editing/groups, both forms, source restoration, variable changes, navigation and exit.
6. Produce a fresh validated `ECEN21.g3a` in isolated M2B artifacts using the existing ARM64 container. Inspect screens and resource/compiler observations; preserve original Logic/shared code and existing checked-in binaries.
7. Record actual results and remaining hardware limits, proactively deliver a Chinese user acceptance guide, and stop for user acceptance. No subsequent milestone is approved.

Execution: one portable-model/test subagent owns only `solver.[ch]`, `solver_checks.[ch]` and its design note; Main Agent owns native UI, build/emulator integration, review and project records. These independent boundaries allow parallel development without concurrent edits. No repeated toolchain investigation.

All seven engineering gates passed on November 12, 2026. Main Agent reviewed the model and added six maximum-depth malformed-editor cases to the subagent's 6,510-check suite: final model count **6,516**, plus **218** unchanged legacy controller checks, all passing on host and SuperH emulator. Exact-engine regression passed **153,092** minimizations. Production smoke produced **59 screenshots** and passed **16** interaction invariants; representative layouts were visually reviewed. The fresh production artifact is `.phase1/ecen21-m2b/artifacts/ECEN21.g3a`, **80,124 bytes**, SHA-256 `05cca11650ee7ebe21debf62f2a471bc6a5df2f1a2ce03bfbf19d233e5de15c8`. See `TESTING.md` for reproducible evidence and scope limits.

User handoff: [M2B physical-calculator acceptance guide](docs/M2B-USER-ACCEPTANCE.zh-CN.md). **M2B user acceptance: explicitly passed** (user stated “M2B检验成功”). The user subsequently chose **“先只确定计划，暂不开始”** for the scoped M3 proposal. At that planning-only checkpoint M3 was not approved; it was subsequently approved by “允许进入M3” as recorded below. No full algebraic proof or support above four variables was added; group explanations show how the selected cube yields its term/clause.

## Milestone 3 — Binary Arithmetic and Signed Numbers (engineering complete; user acceptance pending)

Goal: extend ECEN21 with a bounded integer tool useful for coursework, while retaining the accepted Boolean solver. The latest user instruction “允许进入M3” explicitly authorizes implementation of the scope below; it supersedes the earlier plan-only choice.

### Approved scope and semantics

- **8/16/32-bit widths**, binary/decimal/hexadecimal conversion, signed/unsigned interpretation of the same bits, and two's-complement negative decimal encoding/decoding.
- Two operands A/B; addition and subtraction. Show the retained-width result in all three bases alongside **carry**, **borrow** and **signed overflow**, with clear applicability rather than conflating these flags.
- Arithmetic keeps the low `width` bits. Display an explicit wrap/overflow indication when mathematical results do not fit the selected interpretation; do not silently present a wrapped result as an ordinary exact integer result.
- Decimal input respects the selected signed/unsigned range; hex/binary input specifies the raw bit pattern within the selected width. Empty, malformed, disallowed-digit and out-of-range input gives a clear error and invalidates old results. Base/mode switching preserves the current bit pattern.
- Width increase uses sign extension in signed mode and zero extension in unsigned mode. Width reduction retains low bits and explicitly reports any change to the interpreted value; do not silently lose information. Changing inputs/settings invalidates the old arithmetic result.
- Add a simple Boolean/Binary tool selector. Preserve Boolean state while switching tools. Returning from a tool goes to the selector; exiting the selector returns to the calculator OS. Record this intentional navigation change in the user guide and regression tests.
- Reuse relevant `apps/base-n/` masking, formatting and signed-value conventions through reviewed adaptation, preserving original MIT attribution. Do not modify upstream Base-N/Logic/shared code or existing distribution binaries.
- Excluded: 64-bit mode, octal, multiplication/division, shifts/rotates, general expression arithmetic, one's-complement/sign-magnitude modes, flip-flops/counters/timing/Verilog. Consider these separately after this bounded milestone.

### Execution order

| Step | Work | Completion evidence |
|---|---|---|
| M3.1 | Portable width/input/conversion/flag model, separate from gint | Independent numeric oracle, boundary fixtures and sanitized host checks |
| M3.2 | Tool selector and bounded operand/result views | Correct key flows; Boolean state survives tool switching; errors clear stale output |
| M3.3 | Integration and regression | Shared fixtures pass as SuperH code, existing Boolean suites pass, fresh `.g3a` and emulator checks |
| M3.4 | Delivery and stop | Artifact/hash/resource records and seven-part Chinese physical-user acceptance guide |

Main Agent owns tool navigation/UI, integration and evidence. One independent numeric-core/test subagent owns only numeric.[ch], numeric_checks.[ch] and its design note; no concurrent file edits. Reuse upstream Base-N conventions without editing its sources. Reuse the existing ARM64 Docker toolchain and isolate future artifacts under a new milestone directory. Archive the accepted M2B binary/source/evidence before implementation, not by overwriting its output folder. No calendar completion date is promised before work begins.

### Acceptance examples (engineering checks passed)

| Width / operation | Expected retained result and flags |
|---|---|
| 8-bit signed conversion, decimal `-5` | Hex `FB`, binary `11111011`; same bits mean unsigned251 |
| 8-bit unsigned `255 + 1` | `00`, decimal0; carry=1, signed-overflow=0 |
| 8-bit signed `127 + 1` | `80`, interpreted as -128; signed-overflow=1, carry=0 |
| 8-bit unsigned `0 - 1` | `FF`, interpreted as255; borrow=1, signed-overflow=0 |
| 8-bit signed `-128 - 1` | `7F`, interpreted as127; signed-overflow=1, borrow=0 |
| 16-bit signed `32767 + 1` | `8000`, interpreted as -32768; signed-overflow=1 |
| 32-bit unsigned `4294967295 + 1` | `00000000`; carry=1, signed-overflow=0 |
| 32-bit signed `2147483647 + 1` | `80000000`, interpreted as -2147483648; signed-overflow=1 |
| Invalid input | Binary digit2, excessive width, signed decimal out of range, empty operand: clear error and no stale answer |
| Navigation | Returning to Boolean preserves its expression/manual table/DC/form; module EXIT returns to tool selector |

These examples passed the actual model/target fixture checks. Host-only oracle testing passed **2,359,296 assertions**: every 8-bit pair for both operations and modes (262,144 cases), plus 32,768 deterministic 16/32-bit cases. Shared checks passed **20,779 numeric**, **6,516 Boolean** and **218 legacy** assertions on both host and SuperH emulator. Exact Boolean regression passed **153,092** cases, emulator CTest5/5. Production verification passed **54 numeric/navigation screenshots and15 interaction invariants**; all **59 accepted Boolean screenshots** matched the archived M2B pixels exactly. Representative numeric screens were visually reviewed. See `TESTING.md` for evidence and limits.

Fresh M3 production: `.phase1/ecen21-m3/artifacts/ECEN21.g3a`, **87,652 bytes**, SHA-256 `f309877c3dcd030bd452f11a97d53ab7ccf651d0fb0dcb35706e7f9406b39aed`. No final compiler/Make warnings/errors; target/header validation passed. Original Logic/Base-N/common/exact-engine files and accepted M2A/M2B artifacts remain unchanged. M3 uses a selector and retains both tools' in-memory states; exiting a tool returns to the selector rather than directly to the OS.

Handoff: [M3 Chinese user acceptance guide](docs/M3-USER-ACCEPTANCE.zh-CN.md). **M3 engineering verification: passed. User acceptance: pending. M4 approval: not granted.** Physical hardware behaviour is not inferred from emulation or earlier milestone acceptance.

## M4 proposal — Flip-flop toolkit (planning only; not approved)

Requested planning after M3 delivery does not constitute M3 acceptance or permission to implement M4. Entry gate: explicit M3 acceptance and explicit M4 approval.

Goal: a bounded, single-bit sequential-logic learning tool covering SR, D, JK and T flip-flops. Reuse the existing launcher, gint UI conventions, portable-model/host-test separation and pinned toolchain; retain the accepted Boolean and numeric tools. No upstream Logic/common changes are planned.

Proposed scope:

- Characteristic tables: show inputs, current Q, next Q and a short explanation (hold, set, reset, capture or toggle).
- Excitation tables: given current Q and desired next Q, show the required inputs. Explain X as an input don't-care, distinct from an unknown simulated state.
- Single-step simulation: choose initial Q, inputs, rising/falling active edge and a clock event (none, rising or falling). Only the selected active edge updates Q. Use synchronous, active-high SR semantics; this is not an asynchronous SR latch.
- SR with S=R=1 at an active edge reports an invalid/undefined next state. Do not present a usable binary next state or silently continue the sequence; require reinitialization before further stepping. A retained last-valid value is recovery information, not a claim about physical hardware behaviour.
- Bounded history: at most 16 steps showing inputs, clock event, previous/next state and status. Reject further steps with a clear history-full message until the user clears/reinitializes it. A reset action sets the simulation's initial state and clears history; it is not a physical asynchronous reset pin.
- Add a third launcher entry. Preserve in-memory state when switching tools and provide explicit history clearing and return-to-home actions.

Excluded: asynchronous preset/clear, unknown-state propagation, multiple interconnected flip-flops, counters/FSM synthesis, continuous timing diagrams, electrical propagation/setup/hold/metastability analysis and Verilog generation. These require separately approved scope.

| Stage | Work | Required evidence |
| --- | --- | --- |
| M4.1 | Portable transition and excitation model | Exhaustive independent checks over binary states/inputs and clock events; expand excitation X entries and verify their meaning |
| M4.2 | Tables, explanations and bounded simulation UI | Exact input/output fixtures; invalid-state recovery and history-limit checks |
| M4.3 | Launcher integration and regression | Boolean/numeric regressions, shared target fixtures, emulator interactions and layout inspection |
| M4.4 | Build and acceptance handoff | Fresh production `.g3a`, source manifest/hash/resource observations and seven-part Chinese user guide; stop for acceptance |

Proposed acceptance examples (not executed):

| Case | Expected result |
| --- | --- |
| Rising-edge D, Q=0, D=1, no event or falling edge | Q stays 0; a subsequent rising edge gives Q=1 |
| JK, Q=0, J=K=1, two active edges | Q changes 0 -> 1 -> 0 |
| T, Q=0, T inputs 1,0,1 over three active edges | Q sequence 1,1,0 |
| SR, Q=0, S=1,R=0, then S=R=1 on active edges | First Q=1; then invalid next state, with further stepping blocked until reinitialization |
| Excitation, JK desired transition 1 -> 0 | J=X,K=1; either J value satisfies the transition |
| History/navigation | Exactly 16 entries fit; step 17 is rejected clearly; switching tools preserves state; clearing restores usable simulation |

All four flip-flops' complete characteristic/excitation tables and both active-edge choices must pass exhaustive model checks. Host, emulator and physical results will be recorded separately. User acceptance remains a distinct final gate.

## Future backlog (not approved)

After the proposed M4: counters/sequential design, timing diagrams, Verilog helpers and final integration/release. None is approved. Define each stage's bounded semantics, priorities and acceptance examples before implementation.

## Environment and subsequent work

**Stopped after M3 engineering verification; await M3 user acceptance and explicit next-stage approval.** Fix reported M3 defects if any. No M4 implementation is approved. Preserve all accepted artifacts/evidence. Physical peak-stack/worst-case-latency measurements remain separate unverified hardware work.

Use `bash scripts/toolchain-build-logic.sh` for verified Logic builds; host `make app APP=logic` still requires a native fxSDK installation. Native installation is an optional environment improvement while official forge endpoints remain unavailable. Physical fx-CG50 launch/input/K-map/exit and USB validation remain separate hardware gates.
