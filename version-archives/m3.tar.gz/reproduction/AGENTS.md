# ECEN21 Toolkit engineering workflow

## Communication and ownership

- User-facing updates, questions, explanations, blockers and final reports: Simplified Chinese, with English technical terms where useful.
- Subagent instructions, coordination, reviews and handoffs: English.
- Source/comments, technical documentation, plans, test reports/logs and commit messages: English.
- User acceptance guides are an explicit exception: write them in Simplified Chinese for non-developers.
- Keep communication concise. Summarize relevant findings for the user; do not translate entire internal reports repeatedly.
- The Main Agent owns planning, implementation, delegation, integration, verification and project records.

## Persistent project records

Read `PLAN.md`, `PROGRESS.md`, `TESTING.md` and relevant implementation/design documentation before work. Initial setup also reviewed `docs/ECEN21-PHASE1.md`, `docs/TOOLCHAIN.md` and `docs/BOOLEAN-MINIMIZATION.md`.

- `PLAN.md`: approved milestone, backlog/priorities and acceptance criteria.
- `PROGRESS.md`: completed work, current status, blockers and next actions.
- `TESTING.md`: reproducible procedures, actual results, evidence and limits.
- `AGENTS.md`: persistent engineering rules.

Identify the approved milestone and acceptance criteria, inspect existing code and form a concise execution plan. Work autonomously through its authorized subtasks. After meaningful changes, run relevant tests and append verified results/next actions to the appropriate records. Preserve prior evidence and avoid full-document rewrites for small updates.

## Authorized scope and approval boundaries

Within the approved milestone, inspect/modify project source, create modules/tests, run builds/emulators, debug/fix errors, reasonably refactor new code, update documents and make routine implementation choices without repeated approval.

Stop for user approval before an unapproved milestone, a major architectural change, significant modification of upstream Logic/shared application code, destructive/irreversible actions, physical calculator interaction/manual verification, or a significant unresolved blocker needing a user decision. State the concrete reason and reviewable decision. Do not turn ordinary implementation choices into approval gates.

The user explicitly accepted M2B and approved M3 with **“允许进入M3”**. **M3 engineering verification is complete; M3 user acceptance is pending** in `PLAN.md`. Deliver its seven-part Chinese acceptance guide and stop; remain available for M3 acceptance fixes. M4 and later stages are not approved. Preserve accepted M2A/M2B evidence and distinguish engineering checks, user acceptance and next-milestone approval. Do not infer agent-observed hardware measurements from user acceptance.

## Mandatory milestone user acceptance handoff

After completing each milestone's engineering work, the Main Agent must proactively provide a Simplified Chinese user acceptance guide without waiting for the user to request one. Save a reusable copy in the repository and present actionable instructions in the user-facing handoff, not just a link or a developer test report. Use plain language; assume no knowledge of compilation, Git, terminals or test tools. Explain unavoidable terms and identify the exact user program file rather than a test harness.

Every guide must cover all seven items:

1. Features delivered in this milestone and relevant scope limits.
2. Automated checks actually passed and behaviours not yet verified, clearly distinguishing host tests, emulator execution and physical hardware.
3. How to install or run the delivered program using ordinary user operations; include the artifact location/version and applicable device.
4. A numbered procedure specifying exact keys/inputs and expected visible output at each step, including errors/boundaries and exit where applicable.
5. A clear pass/fail checklist tied to the approved milestone's acceptance criteria.
6. What the user should provide if a step fails: step number, exact input/key sequence, actual versus expected output, photo/error text, device/version if available and repeatability.
7. The next milestone's intended goals and a concise recommendation, explicitly marked as unapproved until authorization arrives.

Keep **engineering verification complete**, **user acceptance pending/passed**, and **next-milestone approval pending/granted** as separate states in `PLAN.md`/`PROGRESS.md`. Preserve existing verified evidence when updating status. Never treat automated success, delivery of a guide, silence or an ambiguous acknowledgement as user acceptance or permission to advance.

Do not begin the next milestone until the user explicitly confirms the current milestone's acceptance AND explicitly approves the next milestone. Both statements may be given in one message; acceptance alone is insufficient. Remain within the current milestone to address acceptance defects and rerun affected checks, then update the guide as needed. Do not operate the physical calculator on the user's behalf without explicit authorization; providing this guide does not count as hardware verification.

## Economical orchestration

Use one Main Agent by default. Spawn subagents only for substantially independent tasks where parallelism has meaningful value and explicit responsibilities, deliverables, acceptance criteria and file/integration ownership are established. Use English delegation. Avoid concurrent edits and duplicate investigations; require verified results, independently review critical outputs and integrate through the Main Agent. Do not simulate a team by assigning redundant roles. Report relevant conclusions to the user in Chinese.

## Engineering and verification

- Prioritize correctness, reproducibility, maintainability and bounded resource use.
- Reuse verified components; preserve `apps/logic/`, upstream shared code and checked-in binaries. Avoid unnecessary dependencies or large refactors. Preserve copyright/license/font attribution.
- Prefer isolated portable C computational modules, separate from gint display/input. Maintain independent host tests and emulator integration tests.
- Reuse the **pinned ARM64 Docker toolchain** from `docs/TOOLCHAIN.md`; do not repeat Phase 1 research or install native macOS tooling unless necessary. No host `fxsdk` installation is assumed.
- Keep generated build/log/screenshot artifacts isolated and ignored; preserve source manifests and artifact hashes. Clear stale outputs so failed runs cannot look successful.
- Run targeted tests during iteration, then relevant regression tests at milestone acceptance. Record exactly what ran, success/failure and material coverage limits. Never invent test success or represent emulator results as physical hardware verification.
- Measure target compilation/resource estimates and runtime where feasible. Clearly distinguish compiler estimates, emulator timing and physical measurements.
- Physical fx-CG50/OS-return/USB behaviour remains unverified until separately approved and actually tested. This does not block software-only acceptance of 2A.
- Stop after the approved milestone and record the next actionable task; do not use scheduled automation to bypass milestone approval.
