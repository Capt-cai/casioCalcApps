#include <gint/display.h>
#include <gint/keyboard.h>
#include "boolean_ui.h"
#include "numeric_ui.h"
#include "info.h"
#include "i18n.h"
#include "utils.h"

#define ACCENT C_RGB(2, 12, 17)

int main(void)
{
    lang_init(); screen_init(); app_name = "ECEN21 Toolkit";
    unsigned selected = 0;
    for(;;) {
        dclear(C_WHITE);
        info_title("ECEN21 Toolkit", ACCENT);
        dtext(14, 33, ACCENT, "Choose a tool");
        drect(10, selected ? 105 : 59, 384, selected ? 145 : 99,
            C_RGB(26, 29, 31));
        dtext(18, 67, C_BLACK, "1  Boolean solver");
        dtext(18, 84, C_DARK, "Expressions, tables, K-map, SOP/POS");
        dtext(18, 113, C_BLACK, "2  Binary / signed numbers");
        dtext(18, 130, C_DARK, "8/16/32-bit conversion and + / -");
        dtext(14, 166, C_DARK, "Tool EXIT returns here; state is retained.");
        dtext(14, 188, C_DARK, "UP/DOWN + EXE | EXIT quits to calculator");
        fkey_button_color(1, "BOOL", ACCENT);
        fkey_button_color(2, "BINARY", ACCENT);
        dupdate();
        int key = getkey().key;
        if(key == KEY_EXIT) return 1;
        if(key == KEY_UP || key == KEY_DOWN) selected ^= 1;
        if(key == KEY_1 || key == KEY_F1) { selected = 0; boolean_run(); }
        else if(key == KEY_2 || key == KEY_F2) { selected = 1; numeric_run(); }
        else if(key == KEY_EXE) {
            if(selected) numeric_run(); else boolean_run();
        }
        else if(key == INFO_KEY) {
            dclear(C_WHITE);
            info_title("About ECEN21 Toolkit", ACCENT);
            dtext(12, 48, C_BLACK, "Boolean and fixed-width integer tools");
            dtext(12, 78, C_DARK, "Based on casioCalcApps (MIT)");
            dtext(12, 100, C_DARK, "Original project: Jose Rodrigues");
            dtext(12, 158, ACCENT, "Press any key to return.");
            dupdate(); getkey();
        }
    }
}
