# ECEN21 Toolkit — Milestone 3

Native fx-CG50 Boolean and bounded integer tools. M2A and M2B were user-accepted; their source/binary/evidence snapshots remain under `.phase1/milestones/`. M3 adds numeric tools without changing the accepted Boolean computation or upstream Logic/Base-N/common/exact-engine sources.

## Tool navigation

The app starts at a selector. Press1/F1 for Boolean,2/F2 for numeric, or use UP/DOWN then EXE. EXIT inside either tool returns to the selector and retains its in-memory state. EXIT at the selector returns to calculator OS. A fresh launch resets both tools; there is no disk persistence. This deliberately adds one navigation level to the M2B exit flow.

## Numeric tool

Two operands support **8/16/32 bits**, **DEC/HEX/BIN**, unsigned or two's-complement signed interpretation, addition and subtraction. Selected-operand conversions are visible before calculation. The result is retained to the selected width with distinct carry, borrow and signed-overflow flags; a selected-mode range warning explicitly marks wrapped arithmetic.

| Key | Action |
|---|---|
| UP/DOWN | Select operand A/B and return to input view |
| Digits; X,theta,T/log/ln/sin/cos/tan | Append0–9 or A–F to selected operand |
| AC / DEL | Clear selected operand / delete its last character |
| (-) or subtraction key | Append minus sign (valid only at start of signed DEC) |
| F1 BASE | DEC -> HEX -> BIN -> DEC; preserve raw bits |
| F2 +/- | Switch addition/subtraction |
| F3 SIGN | Toggle signed/unsigned interpretation of same raw bits |
| F4 WIDTH | 8 ->16 ->32 ->8 bits |
| F5 RESULT/EDIT | Switch views; unsolved/invalid data has no old result |
| EXE / F6 CALC | Calculate with both operands |
| OPTN | Eight known examples;1–8 load, any other key returns unchanged |
| EXIT | Return to tool selector, preserving data |

Typing appends; use AC to replace the selected value. Input base is selected by F1, so no0x/0b prefix is used. Signedness affects decimal interpretation; HEX/BIN represent raw bits. Both operands must be valid before changing base/width/signedness; repair them or use a sample to reset. Invalid digits, empty values, range overflow and excess width are explicitly rejected and clear prior solved output.

Width expansion sign-extends in signed mode and zero-extends unsigned. Shrinking retains low bits and warns if an operand's interpreted value changes. The truncation warning persists through calculation; a successful edit or actual setting change may clear it. Changing any input/setting invalidates the previous arithmetic answer. Carry applies to addition, borrow to subtraction; the other is shown N/A. Signed overflow is shown independently even when unsigned display mode is selected. `Wrapped result` refers to the selected signed/unsigned interpretation, not merely the presence of any flag.

### Numeric examples (OPTN then1–8)

| Sample | Expected calculation/result |
|---|---|
|1|Unsigned8-bit255+1 ->0/00, carry1, signed-overflow0, wrap warning|
|2|Signed8-bit127+1 ->-128/80, carry0, overflow1, wrap warning|
|3|Unsigned8-bit0-1 ->255/FF, borrow1, overflow0, wrap warning|
|4|Signed8-bit-128-1 ->127/7F, borrow0, overflow1, wrap warning|
|5|Signed16-bit32767+1 ->-32768/8000, overflow1|
|6|Unsigned32-bit4294967295+1 ->0/00000000, carry1|
|7|Signed32-bit2147483647+1 ->-2147483648/80000000, overflow1|
|8|Signed8-bit-5+0 ->-5/FB/11111011; unsigned reinterpretation251|

Samples load valid input but do not calculate until EXE/F6. Negative32 minimum and all displayed strings use the portable formatter; no printf64 dependency is required.

## Boolean tool retained

F1 expression,F2 truth table,F3 K-map,F4 results (press again in result view to switch SOP/POS),F5 context action,F6 solve. OPTN samples and all accepted expression/table/DC/group behaviours remain. Only EXIT now returns to the selector; re-entering retains expression, manual truth/DC data, active view and selected form. Full instructions remain in `docs/M2B-USER-ACCEPTANCE.zh-CN.md`, with that exit-flow change applied.

## Architecture and verification

`main.c` is the selector, `boolean_ui.c` retains the accepted Boolean views, `numeric_ui.c` handles numeric keys/drawing, and `numeric.[ch]` is a portable bounded model adapted from Base-N conventions with MIT attribution. Boolean `solver.[ch]` and the existing exact engine are unchanged. A test-only add-in executes shared legacy/Boolean/numeric fixtures and writes an emulator-checkable report; production excludes those test/report sources.

```sh
bash apps/ecen21/tests/run-host.sh
bash apps/ecen21/tests/run-numeric-exhaustive.sh
bash experiments/boolean/run-tests.sh
bash scripts/toolchain-build-m3.sh
/opt/homebrew/bin/python3.11 scripts/verify-m3.py
ctest --test-dir .phase1/emulator-build --output-on-failure
```

Reuse running Docker Desktop, the pinned cached ARM64 toolchain and native emulator from Phase1. Host screenshot checks need Pillow. Production artifact is `.phase1/ecen21-m3/artifacts/ECEN21.g3a`; `EC21Test.g3a` is test-only. Manifests/hashes/logs/screenshots are isolated in the same milestone directory. Generic/old build aliases forward to current M3, avoiding accepted-output overwrite; historical source/helpers remain archived.

`docs/M3-NUMERIC.md` describes exact numeric semantics and oracle coverage; root `TESTING.md` records actual results. See `docs/M3-USER-ACCEPTANCE.zh-CN.md` for non-developer installation/key steps. Physical peak stack, timing, OS return and USB behaviour remain unmeasured by the agent. M3 excludes64-bit mode, octal, multiplication/division, shifts/rotates and future sequential/timing/Verilog tools. Existing MIT/font attribution is preserved.
