# ECEN21 Toolkit — Milestone 4

Native fx-CG50 Boolean, bounded integer and single-bit flip-flop tools. M2A and M2B were user-accepted; their source/binary/evidence snapshots remain under `.phase1/milestones/`. M3 was subsequently user-accepted. M4 adds a separate flip-flop model/UI, retaining numeric tools without changing the accepted Boolean computation or upstream Logic/Base-N/common/exact-engine sources.

## Tool navigation

The app starts at a selector. Press1/F1 for Boolean,2/F2 for numeric,3/F3 for flip-flops, or use UP/DOWN then EXE. EXIT inside any tool returns to the selector and retains its in-memory state. EXIT at the selector returns to calculator OS. A fresh launch resets all tools; there is no disk persistence. This deliberately adds one navigation level to the M2B exit flow.

## Numeric tool

Two operands support **8/16/32 bits**, **DEC/HEX/BIN**, unsigned or two's-complement signed interpretation, addition and subtraction. Selected-operand conversions are visible before calculation. The result is retained to the selected width with distinct carry, borrow and signed-overflow flags; a selected-mode range warning explicitly marks wrapped arithmetic.

| Key | Action |
|---|---|
| UP/DOWN | Select operand A/B and return to input view |
| Digits; X,theta,T/log/ln/sin/cos/tan | Append0–9 or A–F to selected operand |
| AC / DEL | Clear selected operand / delete its last character |
| (-) or subtraction key | Append minus sign (valid only at start of signed DEC) |
| F1 BASE | DEC -> HEX -> BIN -> DEC; preserve raw bits |
| F2 +/- | Switch addition/subtraction |
| F3 SIGN | Toggle signed/unsigned interpretation of same raw bits |
| F4 WIDTH | 8 ->16 ->32 ->8 bits |
| F5 RESULT/EDIT | Switch views; unsolved/invalid data has no old result |
| EXE / F6 CALC | Calculate with both operands |
| OPTN | Eight known examples;1–8 load, any other key returns unchanged |
| EXIT | Return to tool selector, preserving data |

Typing appends; use AC to replace the selected value. Input base is selected by F1, so no0x/0b prefix is used. Signedness affects decimal interpretation; HEX/BIN represent raw bits. Both operands must be valid before changing base/width/signedness; repair them or use a sample to reset. Invalid digits, empty values, range overflow and excess width are explicitly rejected and clear prior solved output.

Width expansion sign-extends in signed mode and zero-extends unsigned. Shrinking retains low bits and warns if an operand's interpreted value changes. The truncation warning persists through calculation; a successful edit or actual setting change may clear it. Changing any input/setting invalidates the previous arithmetic answer. Carry applies to addition, borrow to subtraction; the other is shown N/A. Signed overflow is shown independently even when unsigned display mode is selected. `Wrapped result` refers to the selected signed/unsigned interpretation, not merely the presence of any flag.

### Numeric examples (OPTN then1–8)

| Sample | Expected calculation/result |
|---|---|
|1|Unsigned8-bit255+1 ->0/00, carry1, signed-overflow0, wrap warning|
|2|Signed8-bit127+1 ->-128/80, carry0, overflow1, wrap warning|
|3|Unsigned8-bit0-1 ->255/FF, borrow1, overflow0, wrap warning|
|4|Signed8-bit-128-1 ->127/7F, borrow0, overflow1, wrap warning|
|5|Signed16-bit32767+1 ->-32768/8000, overflow1|
|6|Unsigned32-bit4294967295+1 ->0/00000000, carry1|
|7|Signed32-bit2147483647+1 ->-2147483648/80000000, overflow1|
|8|Signed8-bit-5+0 ->-5/FB/11111011; unsigned reinterpretation251|

Samples load valid input but do not calculate until EXE/F6. Negative32 minimum and all displayed strings use the portable formatter; no printf64 dependency is required.

## Boolean tool retained

F1 expression,F2 truth table,F3 K-map,F4 results (press again in result view to switch SOP/POS),F5 context action,F6 solve. OPTN samples and all accepted expression/table/DC/group behaviours remain. Only EXIT now returns to the selector; re-entering retains expression, manual truth/DC data, active view and selected form. Full instructions remain in `docs/M2B-USER-ACCEPTANCE.zh-CN.md`, with that exit-flow change applied.

## Flip-flop tool (M4)

Portable `flipflop.[ch]` implements one synchronous active-high SR, D, JK or T
flip-flop. Default is D, Q0, input0, active rising edge and rising clock event.
`flipflop_ui.c` renders four views; no upstream/shared sources change.

| Key | Action |
| --- | --- |
| F1 TYPE | Cycle SR -> D -> JK -> T -> SR; changed type starts a new simulation at initial Q, inputs0/eventRISE; active edge retained |
| F2 VIEW | Simulation -> characteristic table -> excitation table -> history -> simulation |
| 1 / 2 | In simulation, toggle input a / b (b only for SR/JK) |
| F3 EDGE | Toggle active rising/falling edge; preserve history |
| F4 RESET | Choose0/1 for initial Q and clear history/invalid lock; other keys cancel; inputs/event/edge retained |
| F5 EVENT | RISE -> FALL -> NONE -> RISE, without stepping |
| EXE / F6 STEP | Record one event in simulation only; preview itself does not update Q |
| UP/DOWN | Select table/history row; wrap across all rows/pages |
| OPTN / EXIT | Help / return home, preserving tool state |

Characteristic tables show next Q for every binary current/input combination on
an active edge. Excitation tables show the inputs needed for each Q -> desired Q
transition. X means either input0 or1, not an unknown current state. `!` denotes
undefined next Q. SR11 is invalid only on the selected active edge in this
synchronous functional model. An invalid SR step records no binary next Q, makes
current Q undefined and blocks subsequent steps until reinitialization or an
explicit type change. Merely changing inputs/edge/event does not recover Q.

Every accepted event, including a hold or invalid SR step, consumes one of16
history entries. Step17 is rejected without overwriting history. Each record
snapshots the active edge and event, shown `R/R`, `R/F`, `F/F`, etc.; R=rising,
F=falling, -=no event. The header shows current settings, which may differ from
historical settings. Restarting clears history and sets Q; this is a simulation
action, not an asynchronous reset/preset pin. No connected multi-flip-flop
circuits, counters, waveforms, electrical timing or Verilog are included.

## Architecture and verification

`main.c` is the three-tool selector; existing Boolean/numeric computation and
views remain unchanged. Portable models are independent of gint. A test-only
add-in executes legacy/Boolean/numeric/flip-flop fixtures and exports an
emulator-checkable report; production excludes test/report code.

```sh
bash apps/ecen21/tests/run-host.sh
bash apps/ecen21/tests/run-numeric-exhaustive.sh
bash experiments/boolean/run-tests.sh
bash scripts/toolchain-build-m4.sh
/opt/homebrew/bin/python3.11 scripts/verify-m4.py
ctest --test-dir .phase1/emulator-build --output-on-failure
```

Reuse the cached ARM64 toolchain and native emulator from Phase1. Screenshot
checks require Pillow. Current outputs use `.phase1/ecen21-m4/`; the user program
is `artifacts/ECEN21.g3a`, not test-only `EC21Test.g3a`. Generic/old build aliases
forward to current M4 to preserve accepted output folders. Original accepted
M3 source/binary/evidence/helpers are archived under `.phase1/milestones/M3/`.
Old-stage verification scripts describe their archived inputs, not current code.

See `docs/M4-FLIPFLOPS.md`, root `TESTING.md` and the Chinese
`docs/M4-USER-ACCEPTANCE.zh-CN.md`. Engineering checks, user acceptance and next
milestone approval remain distinct. Physical timing/stack/USB/OS behaviour is
not inferred from emulation; existing MIT/font attribution is preserved.
