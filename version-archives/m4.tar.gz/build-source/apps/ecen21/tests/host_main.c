#include "controller_checks.h"
#include "solver_checks.h"
#include "numeric_checks.h"
#include "flipflop_checks.h"
#include <stdio.h>

int main(void)
{
    unsigned checks;
    int failed = ec_run_checks(&checks);
    printf("%s: ECEN21 controller; %u checks; failure line %d\n",
        failed ? "FAIL" : "PASS", checks, failed);
    int solver_failed = bs_run_checks(&checks);
    printf("%s: ECEN21 M2B solver; %u checks; failure line %d\n",
        solver_failed ? "FAIL" : "PASS", checks, solver_failed);
    int numeric_failed = nm_run_checks(&checks);
    printf("%s: ECEN21 M3 numeric; %u checks; failure line %d\n",
        numeric_failed ? "FAIL" : "PASS", checks, numeric_failed);
    int flipflop_failed = ff_run_checks(&checks);
    printf("%s: ECEN21 M4 flip-flops; %u checks; failure line %d\n",
        flipflop_failed ? "FAIL" : "PASS", checks, flipflop_failed);
    return failed || solver_failed || numeric_failed || flipflop_failed ? 1 : 0;
}
