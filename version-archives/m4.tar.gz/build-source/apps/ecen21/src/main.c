#include <gint/display.h>
#include <gint/keyboard.h>
#include "boolean_ui.h"
#include "numeric_ui.h"
#include "flipflop_ui.h"
#include "info.h"
#include "i18n.h"
#include "utils.h"

#define ACCENT C_RGB(2, 12, 17)

int main(void)
{
    lang_init(); screen_init(); app_name = "ECEN21 Toolkit";
    unsigned selected = 0;
    for(;;) {
        dclear(C_WHITE);
        info_title("ECEN21 Toolkit", ACCENT);
        dtext(14, 33, ACCENT, "Choose a tool");
        drect(10, 55 + (int)selected * 43, 384, 93 + (int)selected * 43,
            C_RGB(26, 29, 31));
        dtext(18, 61, C_BLACK, "1  Boolean solver");
        dtext(18, 78, C_DARK, "Expressions, tables, K-map, SOP/POS");
        dtext(18, 104, C_BLACK, "2  Binary / signed numbers");
        dtext(18, 121, C_DARK, "8/16/32-bit conversion and + / -");
        dtext(18, 147, C_BLACK, "3  Flip-flops (SR / D / JK / T)");
        dtext(18, 164, C_DARK, "Tables, single steps, 16-step history");
        dtext(14, 188, C_DARK, "Tool EXIT returns here; state is retained.");

        fkey_button_color(1, "BOOL", ACCENT);
        fkey_button_color(2, "BINARY", ACCENT);
        fkey_button_color(3, "FLIP", ACCENT);
        dupdate();
        int key = getkey().key;
        if(key == KEY_EXIT) return 1;
        if(key == KEY_UP) selected = (selected + 2) % 3;
        if(key == KEY_DOWN) selected = (selected + 1) % 3;
        if(key == KEY_1 || key == KEY_F1) { selected = 0; boolean_run(); }
        else if(key == KEY_2 || key == KEY_F2) { selected = 1; numeric_run(); }
        else if(key == KEY_3 || key == KEY_F3) { selected = 2; flipflop_run(); }
        else if(key == KEY_EXE) {
            if(selected == 2) flipflop_run();
            else if(selected == 1) numeric_run(); else boolean_run();
        }
        else if(key == INFO_KEY) {
            dclear(C_WHITE);
            info_title("About ECEN21 Toolkit", ACCENT);
            dtext(12, 48, C_BLACK, "Boolean, numeric and flip-flop tools");
            dtext(12, 78, C_DARK, "Based on casioCalcApps (MIT)");
            dtext(12, 100, C_DARK, "Original project: Jose Rodrigues");
            dtext(12, 158, ACCENT, "Press any key to return.");
            dupdate(); getkey();
        }
    }
}
