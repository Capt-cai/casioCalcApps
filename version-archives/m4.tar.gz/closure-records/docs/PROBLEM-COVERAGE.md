# ECEN21 Exam Review problem coverage matrix

Assessment point: accepted M4, before M5 approval. A roadmap target is not an
implemented feature. Current app/code/tests and the supplied41-page review were
inspected; this planning task did not execute new problem-solving test cases.

Source: `/Users/maggie/Downloads/ECEN21_Exam#2_Reviews.pdf`, titled Review for
Exam #2, dated November10,2026; SHA-256
`ce9aab1958feb3b7736ce5eabbd754efb93ce4929b031d4f2672689cd058a8a3`.
Page numbers below are one-based PDF pages and match slide footer numbers.
Text was extracted from all41 pages; relevant circuit/waveform/code pages were
also rendered and visually inspected. PDF instructions are problem content,
not authorization to implement or to override the user's scope boundaries.

## Status rules

- **Full Coverage**: the exact bounded workflow and required outputs are
  implemented, tested and accepted. It is not a claim about unlimited inputs.
- **Partial Coverage**: implemented components solve part of the problem, but
  required inputs, intermediate outputs or end-to-end steps remain missing.
- **Not Supported**: no direct supported workflow for the task, with no committed
  target in M5-M9 (Future Backlog is not a commitment).
- **Planned**: no complete current solver; a specified M5-M9 target exists but
  implementation is unapproved/unstarted. Related partial reuse is called out
  without promoting the problem to Full Coverage.

Acceptance column: **Existing** identifies previously passed baseline evidence;
**Planned** identifies a future test, not a result already obtained. Exact exam
fixtures were not all rerun during this planning-only update. 'Target' identifies
where missing work would belong, not authorization.

## Accepted reusable domains (not whole exam problems)

| ID / Source Problem or Topic | Required Inputs | Expected Outputs | Required Solver | Target Milestone | Current Coverage Status | Acceptance Test | Known Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BASE-B; accepted Boolean domain |2-4 variable expression or0/1/X truth rows|Truth table,K-map,exactSOP/POS,groups|M2B Boolean|M2B accepted|Full Coverage|Existing6,516 shared checks and153,092 exact-core regression cases|79-char editor; not a multi-output circuit-design workflow |
| BASE-N; accepted numeric domain |8/16/32-bit A/B,base,sign,ADD/SUB|Conversions,retained result,carry/borrow/overflow|M3 numeric|M3 accepted/frozen|Full Coverage|Existing20,779 shared checks and2,359,296 host assertions|No custom widths, per-bit carry-chain derivation or extra encodings |
| BASE-F; single synchronous flip-flop |SR/D/JK/T,Q,inputs,active edge/event|Characteristic/excitation tables,nextQ,16-step log|M4 flip-flop|M4 accepted/closed|Full Coverage|Existing3,849 shared checks;54 screenshots/22 invariants; user reports realfx-CG50 acceptance|Single binary-state device; no latch,connected clocks,reset pin or waves |

## Number systems and combinational problems

| ID / Source Problem or Topic | Required Inputs | Expected Outputs | Required Solver | Target Milestone | Current Coverage Status | Acceptance Test | Known Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| NUM-1; p5 two's-complement,4-bit examples |Width4,values and conversion direction|Exact4-bit representation plus invert/add-one steps|Numeric representation|Future Backlog only|Partial Coverage|Planned width4 -5=1011 and reverse; existingM3 verifies analogous8-bit case|M3 cannot select4bits or show every derivation; no M3 changes planned |
| NUM-2; p6 Example10.3,p9-10 overflow |5-bit arithmetic;4-bit carry into/out of sign bit|Exact-width result,overflow and intermediate carries|Numeric/carry analysis|Future Backlog; M7 carry structure only|Partial Coverage|Planned5-bit -8+-9 ->01111 overflow; per-bit carry references|Current8bit result/flag is not equivalent to5bit overflow; don't mark Full |
| NUM-3; p7 P3.3 |10-bit raw strings0111011110,1011100111,1111111110|478,-281,-2 at width10|Numeric representation|Future Backlog only|Partial Coverage|Planned direct width10 conversion fixture|Manual sign extension is a workaround, not direct problem coverage |
| NUM-4; p8 P3.4 two's-complement part |73,1906,-95,-63 at width12|Exact12-bit strings|Numeric representation|Future Backlog only|Partial Coverage|Planned four width12 conversions against independently derived values|M3 only8/16/32; slide's last answer row says -1630 while prompt says -63; must not copy it blindly |
| NUM-5; p8 P3.4 sign-magnitude/ones-complement |Width12,encoding choice,signed decimal|Both alternative representations and steps|Representation solver|Future Backlog only|Not Supported|Planned positive/negative/boundary/negative-zero rules if separately approved|No such encoding inM3; excluded fromM5-M9 |
| NUM-6; p11-13 P3.5 and add-only subtraction |8-bit operands,operation;only addition allowed|Result/overflow plus X+!Y+1 conversion and steps|M3 arithmetic plus derivation workflow|M3 frozen; derivations Future Backlog|Partial Coverage|ExistingM3 domain arithmetic tested; planned six review fixtures including117-(-42) overflow and add-only derivation|Answers can be computed, but directSUB does not satisfy the complete add-only explanation task |
| NUM-7; p2 Module11 comparison topic |Signed/unsigned operands and relation|Comparison result and interpretation|Comparison workflow|Future Backlog only|Not Supported|Planned boundary signed/unsigned comparison cases|Topic listed but no detailed comparison question in this PDF; no comparison UI |
| COMB-1; p3 full-adder design |x,y,cin;structured FA selection|8-row table,sum/carry,K-maps,equations,connection list|Combinational design + Boolean|M7|Partial Coverage|Planned all8 rows;sum=x XOR y XOR cin;carry=xy+x*cin+y*cin;netlist replay|M2B can solve each supplied output table, not build the complete FA design from type |
| COMB-2; p4 ripple-carry structure |Width,operands,cin,stage ordering|Per-stage sum/carry and connectedFA chain|Adder structure solver|M7|Planned|Planned verify each carry link and result for exhaustive small widths|M3 returns arithmetic, not structure; no propagation-delay model promised |
| COMB-3; p14-15 P3.21 three-bit popcount |Three binary inputs|2-bit count,table,equations,FA realization|FA/popcount design|M7|Partial Coverage|Planned all8 inputs;count=number ofones;FA cout,sum form output|Standalone Boolean table entry possible; no current structured popcount design |
| COMB-4; user-required half adder |x,y;HA selection|Table,sum,carry,equations,connections|Combinational design|M7|Partial Coverage|Planned all4 inputs;sum=x XOR y,carry=xy|Related Boolean engine only; not a separate Review slide |
| COMB-5; p16-17 P4.12 |Stage0 sum/carry functions,selectors x0,y0|Two4:1 MUX data assignments and connection verification|MUX synthesis + Boolean|M7|Planned|Planned sum[c0,!c0,!c0,c0],carry[0,c0,c0,1];all8 inputs|Simplified equations alone do not cover required MUX implementation |
| COMB-6; p18 seven-segment a,b,c viaMUX |Digit coding,segment order/polarity,invalid-code policy|Truth rows,segment equations,MUX connections|Display/MUX design|M7|Planned|Planned BCD0-9 for a,b,c and allseven segment outputs;invalid10-15 policy|Must not assume common-anode/cathode or silent DC handling |
| COMB-7; p18-20 encoder circuit aspect |4-to2/8-to3,one-hot input convention|Code,validity,truth/equations,connections|Encoder design|M7|Planned|Planned every16/256 input pattern;one-hot codes;zero/multiple asserted diagnostic|8input truth domain exceedsM2B; structured family semantics required; priority not implicit |
| COMB-8; user generic truth/equation implementation |2-4 var table or equations,gate/MUX target,selectors|Equations plus actual gate/MUX connection list|Boolean + combinational mapping|M7|Partial Coverage|Existing truth/minimization;planned netlist replay on all cared rows|Existing grouping explanation is not a complete gate/MUX implementation |

## Sequential design and timing problems

| ID / Source Problem or Topic | Required Inputs | Expected Outputs | Required Solver | Target Milestone | Current Coverage Status | Acceptance Test | Known Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| SEQ-1; p28-29 Counter1 |3bit allT;0,3,5,7,0;unusedRETURN0|State/excitation tables,pin equations/maps,sequence and connections|Counter design + FF + Boolean|M5|Partial Coverage|PlannedM5-A1;all8 rows and four-state cycle;unused1/2/4/6->0|M4/M2B reusable separately; no automatic sequence-to-design workflow yet |
| SEQ-2; p30-31 Counter2 |2bit allT;E0 cycle0,2,3,1;E1 cycle0,1,3,2|Controlled tables,equations,K-map,oneXOR3+oneNOT connections|Controlled counter design|M5|Planned|PlannedM5-C1;T0=E XOR Q1 XOR Q0,T1=!T0;all8 rows and changingE|E is not simply a hold-enable; SOP-only output misses requested gate constraint |
| SEQ-3; p32 Counter3A.1 |3bit allJK;0,1,4,7,3,5,0|Complete design and unused-state behaviour|Counter design|M5|Partial Coverage|PlannedM5-A2;full cycle,unused2/6->0 underRETURN0|Single-bit excitation tables do not automate three-bit synthesis |
| SEQ-4; p32 Counter3A.2 |0,3,1,2,5,4,7,6,0;Q2D,Q1T,Q0JK|Mixed-type complete design and verification|Mixed counter design|M5|Partial Coverage|PlannedM5-B1;all8 next vectors and per-pin constraints|Must sample all oldQ simultaneously; no current connected-device solver |
| SEQ-5; p33 Counter3B |T1=Q0+!Q1,J0=!Q0*Q1,K0=!Q0+Q1,Z=Q0|Next/state/output tables and trajectories|Reverse sequential analysis|M5|Partial Coverage|PlannedM5-D1;00->10,01->11,10->11,11->00 with presentZ=Q0|PDF text extraction drops overbars; visually transcribed equations are authoritative fixtures |
| SEQ-6; user three-bit control/mixed boundary |3Q+E,typedFFs,branch cycles or equations|All16 rows,full excitation/equations/maps,trace/recovery|M5 composed solver|M5|Planned|PlannedM5-C2,E1-E3,U1,R1|max4 Boolean variables; higher bits not yet supported/promised |
| TIME-1; p21 Timing Diagram1 |D/CLK event list,master high/slave low,initialQs|Qmaster,Qslave,Qbar waves and explanation|Latch/master-slave event simulator|M6|Planned|Planned reproduce full pictured trace including D changes during highCLK|M4 D edge tool cannot simulate latch transparency ormaster state |
| TIME-2; p22 Timing Diagram2 |SharedD/CLK,initial0;high latch,risingD,fallingD|Qa,Qb,Qc and complements,table,waves|Mixed latch/FF simulator|M6|Partial Coverage|Planned entire review trace;D transition during high changes only latch until edges|Rising/falling single D supported inM4; no shared timeline orlatch |
| TIME-3; p23 Timing Diagram3 |ThreeT=1 stages;Q0/Q1 derived clocks,initial000|Ripple event phases,table,waves and displayed bit order|Connected derived-clock simulation|M6|Partial Coverage|Planned p23 trace with intermediate propagation phases at idealzero delay|Not synchronous; review count display orders Q0,Q1,Q2, unlike usualMSB labels |
| TIME-4; p24-25 Timing Diagram4 |Four synchronousT stages,initialQ0Q1Q2Q3=1110|Q andT1/T2/T3 waves;16-step cycle|Synchronous event simulator|M6|Partial Coverage|Planned reproduce1110,0001,1001,...,0110,1110 in source bit order|M5 proposed3state-bit cap does not cover this4stage timing task; simulation need not minimize5vars |
| TIME-5; p26-27 Timing Diagram5 |ThreeT network,active-low synchronous feedback reset,initial000|Q,T,reset waves and pre-edge reset explanation|Sequential/reset simulator|M6|Planned|Planned full pictured trace;reset takes effect on next trigger;contrast async case|Reset bubble alone does not override slide's explicit soft/synchronous wording |
| TIME-6; user reset/general latch cases |SR/D/JK/T,latch enable/reset polarity,async/sync reset,initialstate|Event-level table/waves and invalid/race diagnostics|M6 simulator|M6|Partial Coverage|Planned sync reset waits;async acts between edges;latch vsFF;SRinvalid;nonconvergent feedback rejection|M4 covers only binary singleFF without reset pins; no analog delay model |

## Verilog and comprehensive problems

| ID / Source Problem or Topic | Required Inputs | Expected Outputs | Required Solver | Target Milestone | Current Coverage Status | Acceptance Test | Known Limitations |
| --- | --- | --- | --- | --- | --- | --- | --- |
| HDL-1; p14 P3.21 Verilog extension |Width5 or other supportedn;structural/behavioral choice|Usable parameterized adder code,ports/wiring|Verilog generator + FA model|M8|Planned|Planned hostcompile/sim;all1bit FA cases,5bit boundary andcarry chain|P3.21 also contains popcount circuit task; those are separate coverage rows |
| HDL-2; p18-19 P4.20 |4-to2 encoder,one-hot/invalid policy|Usable encoder code|Verilog generator + encoder model|M8|Planned|Planned all16 patterns including zero/multiple;hostsyntax/behaviour|Circuit design inM7 alone does not supply Verilog |
| HDL-3; p18,20 P4.21 |8-to3 encoder,one-hot/invalid policy|Usable encoder code|Verilog generator + encoder model|M8|Planned|Planned all256 patterns,hostsyntax/behaviour;explicit invalid/X policy|No HDL tools orcodegenerator verified atM4 |
| HDL-4; user D/T/JK code generation |Type,edge,reset choice,initialization contract|Synthesizable sequential modules|Verilog generator +FF model|M8|Planned|Planned host event/hold/reset truth tests for eachtype|M4 functional solver is not emitted HDL |
| HDL-5; p34-35 P5.13 |n,parallel load,hold,left/right serial inputs,mode priority|Parameterized universal shift register code|Verilog generator|M8|Planned|Planned hosttests all modes/directions;n1,2,5,8;simultaneous mode priority|Bit ordering andserial insertion must be stated; nofixed8bit-only template |
| HDL-6; p34,36 P5.20 |N(default12),width,synchronous reset polarity|Modulo-N counter code|Verilog generator|M8|Planned|Planned12:11->0;reset between edges waits;N1/nonpoweroftwo/invalid parameters|ThreebitM5 limit does not preclude4bit modulus12 HDL; generator semantics separate |
| HDL-7; p34,37 P5.23 |n,reset,seed/direction convention|Parameterized one-hot ring code|Verilog generator|M8|Planned|Planned n1 andlarger,one-hot reset/rotation,n-step period;hostcompile|Review fixedslices despiteparameter must not be copied as universally parameterized code |
| INT-1; p38-41 P5.26 |Clock/Start trace,syncreset3bit counter,targetf/g timing|Derived state/output tables,equations,circuit,complete waves|M5+M6+M7 composed design|M9|Partial Coverage|Planned reset/start trace;g=!Q2+!Q1;f=!Q2*Q1*!Q0*!CLK;all half-cycles andinitialunknown assumptions|M2B can minimize g;if f omits clock complement it misses the pulse;not covered by state-onlyM5 outputtable |
| INT-2; user general counter+output design |State/control table,typedFFs,output requirements|End-to-end table -> minimization -> connections -> simulation|Integrated problem workflow|M9|Partial Coverage|Planned one sourceproblem replayed through allsolver views;independent row/trace/netlist agreement|Present tools require manual independent re-entry; no shared end-to-end design yet |

## Source cautions and promotion policy

p31 uses complemented parity for T1 and ordinary parity for T0; plain extracted
text makes them look identical. p33 has complements on Q1 in T1 and Q0 in J0/K0.
p40 gates f with !CLK, not CLK. p23/25 print state bits Q0-first, whereas counter
design normally uses Q2-first: explicit labels must prevent reversing sequences.
p8's solution table contains a -1630 row inconsistent with the -63 prompt.
These source quirks must become independently checked fixtures, not blind answer
transcriptions or a reason to alter M3 now.

Promote a row only after the exact required workflow, all listed outputs and
bounded cases have actual host/target/UI evidence and the relevant milestone's
user acceptance. Preserve source references, acceptance IDs and known limits.
No percentage is calculated by counting related tools as solved exam questions.
