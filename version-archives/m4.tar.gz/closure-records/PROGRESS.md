# ECEN21 Toolkit progress

Updated November 12, 2026 (America/Los_Angeles).

**Phase 1 software verification: COMPLETE.** A fresh unchanged-source Logic build succeeded and its resulting binary passed emulator verification. Native macOS fxSDK installation and physical fx-CG50 validation remain unverified.

## Current state - M4 closed; M5 planning complete, approval pending

The user explicitly reported that M4 passed realCasio fx-CG50 acceptance and
formally approved closure. Phase1/M2A/M2B/M3/M4 are accepted. No new physical
measurements were supplied and the agent did not operate the device. The
unchanged93,804-byte M4 binary,77-input source copy,original helpers and test/UI
evidence are archived as [stable checkpoint](docs/checkpoints/M4-ACCEPTED.md).
Historical engineering reports remain immutable; separateacceptance.json records
later hardware acceptance. This is a local archive, not a Git tag/remote release.

Planning-only work: inspected the supplied41-page Exam#2 Review (including rendered
circuit/waveform/code pages); created [PRD](PRD.md), [problem coverage matrix](docs/PROBLEM-COVERAGE.md)
and [detailed M5 proposal](docs/M5-PLAN.md). Product route is M5counter/sequential,
M6timing,M7combinational,M8Verilog,M9integration/release. NoM5 source implementation,
M3 changes, new app build or architectural migration was performed. User-requested
custom bit widths/otherM3 improvements are FutureBacklog only, outsideM5-M9.

M5 recommends2-3state bits plus0-1E (max4 Boolean variables), mixedD/T/JK/SR,
explicit unused-state policies and reverse input/output equations. Mandatory
fixtures include all review counters, simultaneous-update traps, recovery/DC
behaviour, exact minimization/maps and connection descriptions. Review overbars
and state-bit ordering were visually checked; no solver coverage was promoted
merely because a reusable engine exists. Requirements/test cases are proposed,
not passed implementation tests. SeeTESTING for checkpoint/document checks.

**M4 engineering: passed. M4 real-device user acceptance: passed; closed.
M5 implementation approval: NOT granted.** Stop after this planning handoff.

## M4 engineering completion record (user subsequently accepted and closed)

The user explicitly stated “M3验收完成 开始M4”: M3 user acceptance passed and M4 approval granted. The scoped flip-flop plan has now passed engineering verification. Accepted M3 source/artifact/evidence and original helpers were archived under `.phase1/milestones/M3/` before integration changes. Main Agent owns the UI, integration and verification; one independent subagent owns the portable flip-flop model/tests/design note. New outputs are isolated under `.phase1/ecen21-m4/`. M5 remains unapproved.

Delivered four flip-flop types, complete characteristic/excitation tables, selected rising/falling active edge and NONE/RISE/FALL events, preview separate from stepping, explicit SR-invalid state/lock, bounded16-entry history with immutable edge/event snapshots, initial-Q restart, help and retained state across three tools. Existing Boolean/numeric views/models and original upstream applications/shared code remain unchanged.

Actual verification: **3,849 flip-flop +20,779 numeric +6,516 Boolean +218 legacy** shared assertions passed both sanitized host and SuperH execution, with identical reports. Independent numeric oracle **2,359,296** assertions, exact Boolean **153,092** cases and emulator CTest **5/5** passed. Production **54 flip-flop screenshots/22 invariants** and **54 numeric/navigation screenshots/15 invariants** passed; all59 Boolean pages and51 numeric-script tool pages match accepted archived pixels. Representative tables, state/error/lock/recovery/history/help/selector screens were visually reviewed. Initial verifier correctly refused stale build provenance after a test-runner output path changed; final clean rebuild and complete verification passed.

Fresh M4 artifact: `.phase1/ecen21-m4/artifacts/ECEN21.g3a`, **93,804 bytes**, SHA-256 `165a5a2230b075352046e0f666b9b9d981d47b99c69af06443373fcadefcff6f`. Final compiler/Make/header/manifest checks passed. ELF text64,664/data464/BSS2,672; step68-byte compiler frame, flip-flop UI120-byte frame. No physical peak/latency claim is made. [Chinese M4 acceptance guide](docs/M4-USER-ACCEPTANCE.zh-CN.md) provides exact install/keys/results and failure reporting. **M4 engineering passed; hardware user acceptance subsequently passed and closure approved; M5 implementation unapproved.** Original results are retained; see current closure/checkpoint record above.

## M3 engineering complete; user subsequently accepted

The latest user instruction “允许进入M3” explicitly authorizes the scoped numeric milestone, superseding the prior plan-only choice. M2B is user accepted. Its source/binary/evidence and helper snapshots are preserved under `.phase1/milestones/M2B/`; M3 output uses `.phase1/ecen21-m3/`.

One independent numeric-model/test subagent completed its owned files; Main Agent reviewed the code, independently reran the suites, implemented launcher/numeric views, extracted Boolean UI without changing its computations, and verified integration. No upstream Logic/Base-N/common or exact-engine modifications were needed.

Delivered: 8/16/32-bit DEC/HEX/BIN input/conversion; signed/unsigned reinterpretation; two's-complement negatives; A/B addition/subtraction; distinct carry/borrow/signed-overflow and selected-mode wrapping; sign/zero extension; meaningful truncation warnings; explicit invalid/empty/range errors with stale-output clearing; eight numeric samples; tool selector preserving both tools' in-memory states. Module EXIT returns to selector; selector EXIT returns to calculator. No disk persistence or out-of-scope64-bit/multiply/divide/shift features were added.

Verification passed: shared **20,779 numeric +6,516 Boolean +218 legacy** checks on both sanitized host and SuperH emulator; **2,359,296** independent host arithmetic-oracle assertions (all8-bit pairs/operations/modes plus sampled16/32); Boolean exact regression **153,092** cases; emulator CTest **5/5**. Production generated **54** numeric/navigation screenshots with **15** interaction invariants, and **59** Boolean screenshots exactly matched the accepted M2B reference. Representative input/result/error/negative/32-bit/truncation/selector pages were visually inspected.

Fresh output: `.phase1/ecen21-m3/artifacts/ECEN21.g3a`, **87,652 bytes**, SHA-256 `f309877c3dcd030bd452f11a97d53ab7ccf651d0fb0dcb35706e7f9406b39aed`. Final build has no warnings/errors and both add-ins pass packaging checks. ELF text=58,512 bytes, data=464, BSS=2,048. Numeric parse/format/solve frames are64/84/40 bytes; numeric view128, launcher44; these are compiler observations, not measured physical peaks. The numeric model uses no heap/recursion.

Accepted M2A/M2B and Phase1 evidence are preserved; current build aliases route to M3 output so earlier delivery folders are not overwritten. Handoff: [M3 Chinese acceptance guide](docs/M3-USER-ACCEPTANCE.zh-CN.md). **Engineering verification: passed. M3 user acceptance: subsequently passed. M4 approval: subsequently granted.** This preserves the M3 delivery record; current M4 status is above. Hardware OS return, speed, stability, USB and peak stack remain unmeasured by the agent for this version.

## M4 planning-only checkpoint

The user requested an M4 plan after M3 delivery. `PLAN.md` now proposes single-bit SR/D/JK/T characteristic/excitation tables and bounded edge-based simulation, with explicit invalid-state handling, exclusions, stages and acceptance fixtures. At that checkpoint no M4 implementation/tests were started, M3 acceptance was pending and M4 unapproved. This historical plan-only state was subsequently superseded by explicit M3 acceptance/M4 approval and the completed engineering work above.

## M2B engineering completion record (user subsequently accepted)

The user explicitly confirmed M2A acceptance and approved M2B ("M2A验收通过 批准进入M2B"). M2A engineering evidence is preserved under both `.phase1/ecen21/` and `.phase1/milestones/M2A/`; no new physical measurements are inferred from this acceptance statement.

M2B acceptance criteria are in `PLAN.md`. A single portable-model/test subagent owns solver/parser and its fixtures; Main Agent owns native UI, integration, build verification and handoff. The exact minimizer, original Logic/shared sources and checked-in binaries remain unchanged. Fresh M2B artifacts/evidence use `.phase1/ecen21-m2b/` to preserve M2A.

Delivered: 79-character expression/cursor editor; syntax diagnostics; active 2/3/4 variables; editable 0/1/X truth table and synchronized Gray-order K-map; exact SOP/POS with cared-row verification; all-group navigation and cube-to-term/clause explanations; term/clause-aware long-result wrapping; samples/help and exit. EXPR/MANUAL source is explicit, and navigation cannot silently restore saved text. Manual variable shrink retains low rows only, while expression variable changes re-evaluate text.

The independent subagent completed portable model/parser and tests; Main Agent reviewed/integrated them, added six malformed maximum-depth cases, reran the sanitized host suite, implemented native views and verified SuperH execution and screenshots. Final checks: **6,516 model + 218 legacy checks** pass on both host and target emulator; **153,092** exact-core cases pass; **59** production screenshots and **16** interaction invariants pass; emulator CTest **5/5**. Representative screens including errors, 2/3/4-variable maps, wraparound groups, eight-group navigation, all-DC and long POS were visually inspected. Final build has no compiler/Make warnings/errors, and both add-ins' header checks pass.

M2B deliverable: `.phase1/ecen21-m2b/artifacts/ECEN21.g3a`, **80,124 bytes**, SHA-256 `05cca11650ee7ebe21debf62f2a471bc6a5df2f1a2ce03bfbf19d233e5de15c8`. Resources: ELF text=50,984 bytes, data=464, BSS=1,856. Main frame=224 bytes; parser/minimizer estimates are detailed in `TESTING.md`. Tests execute bounded deepest malformed expressions on SuperH; physical peak stack/latency remain unmeasured.

M2A original/archive binaries and Phase 1 evidence remain intact. The generic `toolchain-build-ecen21.sh` now forwards to the M2B build driver so it cannot overwrite the accepted M2A output path; the original M2A helpers are archived under `.phase1/milestones/M2A/reproduction/`. No upstream Logic/common/exact-engine changes were made.

**M2B engineering verification: passed. M2B user acceptance: explicitly passed.** The prior M3 planning-only checkpoint was superseded by the explicit approval and current M3 results above. The [Chinese M2B acceptance guide](docs/M2B-USER-ACCEPTANCE.zh-CN.md) is retained with prior evidence. This historical paragraph preserves the planning-only handoff; current authorization/results are recorded above.

## M2A engineering completion record (user subsequently accepted)

Milestone 2A finished on November 12, 2026. Work used one Main Agent, consistent with the economical workflow; no subagents or new native-toolchain research were needed.

- Added repository `AGENTS.md` covering communication language, milestone approval, autonomous execution, economical delegation, verification and preservation rules.
- Added `apps/ecen21/`: native gint UI, portable input/controller, custom menu icons, user documentation, shared host/target controller fixtures and emulator key script.
- The app directly links the existing verified Boolean engine in `experiments/boolean/`; no algorithm copy, original Logic changes or shared-source changes were required.
- Users can enter/edit a four-digit hexadecimal ON-mask, compute exact SOP, load the known counterexample or constants, inspect cost, open About and exit. Each successful target calculation verifies all 16 truth-table rows. POS/DC editing, expression editor, tables and K-maps remain outside 2A.
- Fresh `ECEN21.g3a`: **72,532 bytes**, SHA-256 `a1a9705e202ca0e33329b1e0c899e13084c5899e9583b29b164a8bc4b0a6fbc5`, at `.phase1/ecen21/artifacts/ECEN21.g3a`. The pinned ARM64 Docker route built production and a separate test-only add-in successfully.
- Host exact-core regression passed 153,092 minimizations / 2,237,318 cared-row checks with ASan/UBSan. The controller passed 218 sanitized host checks and the identical 218 checks executing as SuperH code in the emulator, with its output file checked against the passing host report.
- Production emulator smoke passed: 12 screenshots, six automated interaction invariants, normal exit and visual layout review. `007E` actually computes `A'C'D+A'BD'+A'B'C` (three terms/nine literals); `6996` shows eight terms/32 literals with readable wrapping. Emulator infrastructure CTest passed 5/5.
- The initial bind-mounted build emitted Make clock-skew warnings. Building on Linux tmpfs resolved them; the final clean build has no compiler or Make warnings/errors. The known emulator trailing-unused-key diagnostic remains documented.
- Static target estimates: text 43,392 bytes, data 464, BSS 1,280; main 104 bytes, controller solve 36, minimizer 892 and recursive visit 112 bytes/frame. Physical peak stack, worst-case latency, OS return and USB remain unverified.
- Hash verification confirms tracked upstream Logic/common files and all existing distribution binaries are unchanged. Phase 1 artifacts/evidence were preserved. See `TESTING.md` and `apps/ecen21/README.md` for reproduction.

**Engineering verification: passed. User acceptance: explicitly passed. M2B approval: explicitly granted.** Added the permanent seven-part Chinese acceptance-guide policy to `AGENTS.md` and delivered [the M2A physical-calculator acceptance guide](docs/M2A-USER-ACCEPTANCE.zh-CN.md). Its installation instructions were checked against Casio's official add-in installation guide and its application expectations against the actual code/test evidence. The existing artifact's SHA-256 was reconfirmed; no application rebuild or new physical test was performed for this documentation change. Prior evidence is preserved.

The user has now provided both required confirmations, so work advances only to M2B. Its completion will require a new acceptance handoff and approval gate.

## Baseline

- Repository revision: `12d6b4e1086746534636c3bb87703deeef5734a8`.
- Existing Phase 1 changes were preserved: report, host audit script, emulator helper and `.phase1/` ignore rule.
- The earlier prebuilt Logic demo and five emulator infrastructure tests passed; those results do not demonstrate a source build.
- Exactly two subagents were actually launched in parallel: Toolchain Engineer and Algorithm Engineer. Their files have separate ownership; the lead owns integration and status documentation.
- Before delegation work, the lead recorded SHA-256 baselines for tracked Logic/shared files and the distribution binary under `.phase1/lead/`.

## Phase 1 verified results (historical record)

The following records describe the completed Phase 1 handoff; the 2A section above supersedes its earlier calculator-integration status.

Agent A resolved the source-build blocker with a complete pinned **ARM64 Linux container on Docker Desktop**. Tool versions: fxSDK 2.11.0, GCC 14.1.0, binutils 2.42, gint 2.11.0 and fxlibc 1.5.1. The image manifest is `manawyrm/fxsdk@sha256:292176e823e272b87b74f3e87b0c2ee26d4ada17abec017e98002c207a456227`. Source copy, compiler host and SuperH target were separately verified. A fresh build succeeded without compiler warnings/errors; header checks passed. The original distribution binary was preserved.

Fresh deliverable: `.phase1/toolchain/artifacts/Logic.g3a`, **85,716 bytes**, SHA-256 `100b83beaa5dd6051cebdecfb816df8946d60bd6afa66ea884691ca56fd98b25`. Both Agent A and the lead ran this final artifact in the native arm64 emulator: exit 0, all five screenshots exactly matched reference pixels. The lead also visually inspected fresh expression/K-map output. The initial amd64-container build was separately successful; ARM64 is the preferred verified route.

Agent B finished an isolated portable C exact minimizer in `experiments/boolean/`, with SOP, POS and don't-cares for 2–4 variables. The lead reviewed the search completeness, prime restriction, polarity and pruning rules, then independently reran its sanitized suite: **153,092 minimizations and 2,237,318 cared-row checks passed**. The known `0x007e` counterexample yields three terms/nine literals, matching the lead's independent all-cube subset calculation. Full four-variable don't-care coverage is sampled, not exhaustive. Calculator integration and target resource measurements remain pending.

The lead also reran the existing Logic audit (65,808 equivalent covers, 2,288 nonminimal four-variable covers) and the five available emulator tests successfully. The new exact core compiled cleanly to SuperH with strict warnings: 1,524 text bytes, zero data/BSS, static stack estimates 892 bytes for `eb_minimize` and 112 bytes per recursive frame. No calculator application links this experimental core yet.

Both agents finished before final integration. The lead reviewed their code/design and confirmed all 49 isolated build inputs matched workspace originals. Tracked Logic/shared source and the checked-in prebuilt still match the entry hash baselines. Integrated additions are the isolated experiment, build/verification helpers, detailed design/toolchain reports and these project status documents; no ECEN21 UI or existing Logic feature changes were made.

## Remaining work after 2A (historical; current state above)

- Full native macOS fxSDK/GCC installation is unverified; official forge HTTP requests still time out. The working container route avoids this blocker for application source builds.
- Physical fx-CG50 execution, OS return and USB operation remain untested.
- Exact-core peak stack and worst-case latency need calculator runtime measurements; all four-variable ternary specifications were not exhaustively tested.
- The existing Logic app retains its original greedy algorithm. ECEN21 M2B exposes the complete bounded expression/table/K-map/SOP/POS/DC workflow; the user has accepted this version.

**Next task:** await explicit approval of the proposed M5 scope/acceptance plan; do not implement M5 or change M3 before that approval. See [PLAN.md](PLAN.md).

Detailed initial findings remain in [the historical Phase 1 report](docs/ECEN21-PHASE1.md). Current evidence is in [TOOLCHAIN.md](docs/TOOLCHAIN.md), [BOOLEAN-MINIMIZATION.md](docs/BOOLEAN-MINIMIZATION.md) and [TESTING.md](TESTING.md).
