
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/build-source/common/src/fmt.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/fmt.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/fmt.c.obj.d"
  "/work/build-source/common/src/form.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/form.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/form.c.obj.d"
  "/work/build-source/common/src/i18n.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/i18n.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/i18n.c.obj.d"
  "/work/build-source/common/src/info.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/info.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/info.c.obj.d"
  "/work/build-source/common/src/keys.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/keys.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/keys.c.obj.d"
  "/work/build-source/common/src/menu.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/menu.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/menu.c.obj.d"
  "/work/build-source/common/src/numfield.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/numfield.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/numfield.c.obj.d"
  "/work/build-source/common/src/ui.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/ui.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/ui.c.obj.d"
  "/work/build-source/common/src/units.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/units.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/units.c.obj.d"
  "/work/build-source/common/src/usb_screen.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/usb_screen.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/usb_screen.c.obj.d"
  "/work/build-source/common/src/utils.c" "CMakeFiles/casio_common.dir/work/build-source/common/src/utils.c.obj" "gcc" "CMakeFiles/casio_common.dir/work/build-source/common/src/utils.c.obj.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
