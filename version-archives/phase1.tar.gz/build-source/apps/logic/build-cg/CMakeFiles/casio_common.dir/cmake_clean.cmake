file(REMOVE_RECURSE
  "CMakeFiles/casio_common.dir/work/build-source/common/src/fmt.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/fmt.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/form.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/form.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/i18n.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/i18n.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/info.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/info.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/keys.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/keys.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/menu.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/menu.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/numfield.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/numfield.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/ui.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/ui.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/units.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/units.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/usb_screen.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/usb_screen.c.obj.d"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/utils.c.obj"
  "CMakeFiles/casio_common.dir/work/build-source/common/src/utils.c.obj.d"
  "libcasio_common.a"
  "libcasio_common.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/casio_common.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
