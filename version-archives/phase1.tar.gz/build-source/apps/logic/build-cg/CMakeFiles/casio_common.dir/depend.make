# Empty dependencies file for casio_common.
# This may be replaced when dependencies are built.
