CMakeFiles/casio_common.dir/work/build-source/common/src/keys.c.obj: \
 /work/build-source/common/src/keys.c \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/keyboard.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/types.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/attributes.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stddef.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint-gcc.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdbool.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/sys/types.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdarg.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/keycodes.h \
 /work/build-source/common/include/keys.h
