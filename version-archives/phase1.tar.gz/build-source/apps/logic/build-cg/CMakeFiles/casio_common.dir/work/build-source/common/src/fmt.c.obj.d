CMakeFiles/casio_common.dir/work/build-source/common/src/fmt.c.obj: \
 /work/build-source/common/src/fmt.c \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/math.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/openlibm_math.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/openlibm_defs.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/stdio.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stddef.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdarg.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint-gcc.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/sys/types.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/string.h \
 /work/build-source/common/include/fmt.h
