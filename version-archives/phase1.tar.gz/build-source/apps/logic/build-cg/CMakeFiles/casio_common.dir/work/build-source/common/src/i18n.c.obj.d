CMakeFiles/casio_common.dir/work/build-source/common/src/i18n.c.obj: \
 /work/build-source/common/src/i18n.c \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/gint.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/types.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/attributes.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stddef.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint-gcc.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdbool.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/sys/types.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdarg.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/call.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/config.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/intc.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/string.h \
 /work/build-source/common/include/i18n.h
