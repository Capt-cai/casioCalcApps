CMakeFiles/casio_common.dir/work/build-source/common/src/utils.c.obj: \
 /work/build-source/common/src/utils.c \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/display.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/types.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/attributes.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stddef.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdint-gcc.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdbool.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/sys/types.h \
 /root/.local/share/fxsdk/sysroot/lib/gcc/sh3eb-elf/14.1.0/include/stdarg.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/defs/call.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/config.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/display-cg.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/image.h \
 /root/.local/share/fxsdk/sysroot/sh3eb-elf/include/gint/gray.h \
 /work/build-source/common/include/utils.h \
 /work/build-source/common/include/color.h
