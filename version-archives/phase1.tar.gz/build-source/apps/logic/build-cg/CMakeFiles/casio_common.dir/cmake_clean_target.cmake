file(REMOVE_RECURSE
  "libcasio_common.a"
)
