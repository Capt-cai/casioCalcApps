
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "FXCONV"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_FXCONV
  "/work/build-source/common/assets-cg/font_big.png" "/work/build-source/apps/logic/build-cg/CMakeFiles/Logic.dir/work/build-source/common/assets-cg/font_big.png.o"
  "/work/build-source/common/assets-cg/qr_repo.png" "/work/build-source/apps/logic/build-cg/CMakeFiles/Logic.dir/work/build-source/common/assets-cg/qr_repo.png.o"
  )

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_FXCONV
  "FXCG50"
  "TARGET_FXCG50"
  )

# The include file search paths:
set(CMAKE_FXCONV_TARGET_INCLUDE_PATH
  "/work/build-source/common/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/work/build-source/apps/logic/src/main.c" "CMakeFiles/Logic.dir/src/main.c.obj" "gcc" "CMakeFiles/Logic.dir/src/main.c.obj.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/work/build-source/apps/logic/build-cg/CMakeFiles/casio_common.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
