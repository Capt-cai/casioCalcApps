file(REMOVE_RECURSE
  "CMakeFiles/Logic.dir/src/main.c.obj"
  "CMakeFiles/Logic.dir/src/main.c.obj.d"
  "CMakeFiles/Logic.dir/work/build-source/common/assets-cg/font_big.png.o"
  "CMakeFiles/Logic.dir/work/build-source/common/assets-cg/qr_repo.png.o"
  "Logic"
  "Logic.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C FXCONV)
  include(CMakeFiles/Logic.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
