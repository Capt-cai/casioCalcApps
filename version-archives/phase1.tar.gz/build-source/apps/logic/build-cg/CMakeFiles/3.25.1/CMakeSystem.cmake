set(CMAKE_HOST_SYSTEM "Linux-6.12.76-linuxkit")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.12.76-linuxkit")
set(CMAKE_HOST_SYSTEM_PROCESSOR "aarch64")

include("/root/.local/lib/cmake/fxsdk/FXCG50.cmake")

set(CMAKE_SYSTEM "Generic-1")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "sh")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
