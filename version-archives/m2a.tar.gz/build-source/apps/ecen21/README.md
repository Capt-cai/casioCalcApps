# ECEN21 Toolkit — Milestone 2A

A native colour fx-CG50 add-in for exact four-variable SOP minimization. This is the approved minimal application, not the complete Boolean solver.

## Input and calculation

Enter a 1–4 digit hexadecimal ON-mask. Bit `r` is the output for truth-table row `r`, with A as the most significant variable bit in `(A,B,C,D)`. For example `007E` means ON rows `{1,2,3,4,5,6}`. All other rows are OFF; this minimal UI does not edit don't-cares.

| Key | Action |
|---|---|
| `0`–`9` | Enter a hex digit |
| X,θ,T / log / ln / sin / cos / tan | Enter A / B / C / D / E / F (no ALPHA needed) |
| EXE or F6 | Calculate exact SOP; verify the result against all 16 rows |
| F1 | Load `007E`, the Phase 1 greedy-counterexample demo |
| F2 / F3 | Load `0000` / `FFFF` |
| DEL / AC | Delete one digit / clear input |
| OPTN | About; any key returns |
| EXIT | Quit the app |

The first digit typed after a preset or completed calculation replaces the previous input. Further digits append, up to four. Editing invalidates the displayed result. An empty field cannot be solved. Load and solve are separate actions.

For `007E`, the computed result is `A'C'D+A'BD'+A'B'C`, with **three terms and nine literals**. For `6996`, parity requires eight terms and 32 literals. Constants format as `0` and `1`; the constant-zero empty cover has zero terms, while the unconstrained constant-one cube has one term and zero literals.

## Architecture

- `src/main.c`: gint display/key adapter using shared title, font, colour and F-key conventions.
- `src/controller.[ch]`: portable bounded input/calculation state; no gint dependency.
- `../../experiments/boolean/exact_boolean.[ch]`: the existing verified engine, linked directly without a second copy or algorithm changes. The host oracle tests exercise the same source.
- `tests/`: shared host/SuperH controller fixtures plus a test-only native add-in. Test reporting and BFile calls are excluded from the production app.

The exact engine supports SOP/POS/DC internally; only SOP with an editable ON-mask is exposed in 2A. Expression editing, truth tables, K-maps and full POS/DC editing are Milestone 2B and have not been started. Original Logic/shared sources and existing distribution binaries remain unchanged. Reuse is covered by the repository MIT license and existing font attribution.

## Build and verify

Reuse the Phase 1 cached ARM64 Docker image and native emulator:

```sh
bash apps/ecen21/tests/run-host.sh
bash experiments/boolean/run-tests.sh
bash scripts/toolchain-build-ecen21.sh
/opt/homebrew/bin/python3.11 scripts/toolchain-verify-ecen21.py
```

Docker Desktop must be running. No native macOS fxSDK installation is required. The last command needs Pillow and the Phase 1 emulator build. Generated artifacts, hashes, manifests, logs and screenshots are in `.phase1/ecen21/`; production output is `.phase1/ecen21/artifacts/ECEN21.g3a`. The separate `EC21Test.g3a` is an automated-test harness, not the user application. The build uses Linux tmpfs inside the network-disabled container to avoid bind-mount clock-skew warnings. Date/time metadata can change a successful rebuild's hash.

With a native fxSDK installed, the normal repository `make app APP=ecen21` path is also configured by CMake, but only the pinned container path was verified on this Mac.

Physical calculator execution, OS return, keyboard feel, USB and peak stack/latency are unverified. Emulator checks and compiler estimates do not certify those hardware behaviours. See root `TESTING.md` for measured results and evidence.
