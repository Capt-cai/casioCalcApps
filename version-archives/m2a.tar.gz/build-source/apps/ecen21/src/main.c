#include <gint/display.h>
#include <gint/keyboard.h>
#include <string.h>

#include "controller.h"
#include "info.h"
#include "i18n.h"
#include "keys.h"
#include "utils.h"

#define ACCENT C_RGB(2, 12, 17)

static void about(void)
{
    dclear(C_WHITE);
    info_title("About ECEN21", ACCENT);
    dtext(10, 36, ACCENT, "ECEN21 Toolkit - Exact SOP");
    dtext(10, 62, C_BLACK, "Based on casioCalcApps (MIT)");
    dtext(10, 80, C_DARK, "Original project: Jose Rodrigues");
    dtext(10, 106, C_BLACK, "Exact core: ECEN21 Boolean prototype");
    dtext(10, 132, C_DARK, "Built " __DATE__ " " __TIME__);
    dtext(10, 178, C_DARK, "Press any key to return.");
    dupdate();
    getkey();
}

static void draw(ec_state const *state)
{
    dclear(C_WHITE);
    info_title("ECEN21 Toolkit", ACCENT);
    dtext(10, 28, ACCENT, "Exact SOP minimizer");
    dtext(10, 45, C_DARK, "F(A,B,C,D); A is the row MSB.");
    dtext(10, 71, C_BLACK, "ON mask (hex):");
    drect_border(256, 60, 384, 86, C_WHITE, 1, ACCENT);
    font_t const *old = dfont(&font_big);
    dtext(264, 66, C_BLACK, state->input[0] ? state->input : "_");
    dfont(old);
    dtext(10, 95, C_DARK, "Bit r of the mask is F(row r), r=0..15.");
    dline(10, 110, 384, 110, C_LIGHT);

    if(state->status == EC_SOLVED) {
        dtext(10, 120, ACCENT, "Minimal SOP:");
        size_t length = strlen(state->sop);
        for(size_t offset = 0, line = 0; offset < length && line < 4; line++) {
            char text[45];
            size_t count = length - offset;
            if(count > 44) count = 44;
            memcpy(text, state->sop + offset, count);
            text[count] = '\0';
            dtext(10, 138 + (int)line * 13, C_BLACK, text);
            offset += count;
        }
        dprint(10, 193, ACCENT, "%d terms | %d literals | %d rows checked",
            (int)state->result.count, (int)state->result.literals,
            (int)state->verified_rows);
    }
    else {
        dtext(10, 125, state->status == EC_READY ? ACCENT : C_RED,
            state->status == EC_EMPTY ? "Enter an ON mask first." :
            state->status == EC_ERROR ? "Calculation failed. Reload the demo." :
            "Enter a mask, then press EXE.");
        dtext(10, 151, C_DARK, "0-9; X/log/ln/sin/cos/tan type A-F.");
        dtext(10, 169, C_DARK, "DEL deletes. AC clears. EXIT quits.");
        dtext(10, 193, C_DARK, "New digits replace a preset or solved input.");
    }
    fkey_button(1, "DEMO");
    fkey_button(2, "ZERO");
    fkey_button(3, "ALL");
    fkey_button_color(6, "SOLVE", ACCENT);
    dupdate();
}

int main(void)
{
    static ec_state state;
    lang_init();
    screen_init();
    app_name = "ECEN21 Toolkit";
    ec_load(&state, 0x007e);
    for(;;) {
        draw(&state);
        int key = getkey().key;
        if(key == KEY_EXIT) return 1;
        if(key == INFO_KEY) { about(); continue; }
        if(key == KEY_F1) ec_load(&state, 0x007e);
        else if(key == KEY_F2) ec_load(&state, 0);
        else if(key == KEY_F3) ec_load(&state, 0xffff);
        else if(key == KEY_EXE || key == KEY_F6) ec_solve(&state);
        else if(key == KEY_DEL) ec_backspace(&state);
        else if(key == KEY_ACON) ec_clear(&state);
        else {
            int digit = key_hex(key);
            if(digit >= 0) ec_digit(&state, (unsigned)digit);
        }
    }
}
