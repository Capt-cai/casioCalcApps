/* Test-only add-in: run the same controller fixtures on SuperH and export
 * a marker through the emulated OS. Not linked into the production app. */
#include "controller_checks.h"
#include <gint/bfile.h>
#include <gint/display.h>
#include <gint/gint.h>
#include <stdio.h>
#include <string.h>

static char report[96];
static int save_report(void)
{
    uint16_t const path[] = u"\\\\fls0\\ECEN21.txt";
    int size = (int)strlen(report);
    BFile_Remove(path);
    if(BFile_Create(path, BFile_File, &size) < 0) return -1;
    int fd = BFile_Open(path, BFile_WriteOnly);
    if(fd < 0) return -1;
    int rc = BFile_Write(fd, report, size);
    BFile_Close(fd);
    return rc < 0 ? -1 : 0;
}

int main(void)
{
    unsigned checks;
    int failed = ec_run_checks(&checks);
    snprintf(report, sizeof report,
        "%s: ECEN21 controller; %u checks; failure line %d\n",
        failed ? "FAIL" : "PASS", checks, failed);
    int saved = gint_world_switch(GINT_CALL(save_report));
    dclear(C_WHITE);
    dtext(8, 30, failed || saved ? C_RED : C_GREEN, report);
    dupdate();
    return failed || saved ? 1 : 0;
}
