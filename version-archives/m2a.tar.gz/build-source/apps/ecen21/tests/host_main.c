#include "controller_checks.h"
#include <stdio.h>

int main(void)
{
    unsigned checks;
    int failed = ec_run_checks(&checks);
    printf("%s: ECEN21 controller; %u checks; failure line %d\n",
        failed ? "FAIL" : "PASS", checks, failed);
    return failed ? 1 : 0;
}
